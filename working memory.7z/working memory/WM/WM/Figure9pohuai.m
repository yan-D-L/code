% Lo script richiede che siano gi� costruiti i pattern si faccia uso della prima sezione
% di MAIN a tal scopo.
clc
close all
clear

MAIN

%% TEST COND. ANOMALA - patologia Alzheimer
clc

train_flag=0 ;
load_sinapsi
t_sim=0.8;
dt=0.0001;
t=0:dt:t_sim;

 A_L2L2=A_L2L2*0.68;
 A_L3L3=A_L3L3*0.68;
coeff_Cep=1;
coeff_Cpe=1;
coeff_Csp=1;%sp 和ps为1，其他为0.5也OK
coeff_Cps=1;
coeff_Cfs=1;
coeff_Cfp=1;
coeff_Cpf=1;%0.1
 coeff_Cff=1;
Wp_L2L1=1*Wp_L2L1;%耦合会显著变小
Wp_L1WM=1*Wp_L1WM;
Wp_WML1=1*Wp_WML1;
Wp_L3L2=1*Wp_L3L2;
INPUT_WM=zeros(numero_colonne,8001);
buff=zeros(numero_colonne, round(0.05/dt));
pos=find(corrupt_pattern(all_patterns(:,5))==1);
buff(pos,:)=1;
INPUT_WM(:,51:550)=buff;


reteWM_sim_pat,
save ('figure13.mat')
IN0=INPUT_WM*125+np0;
line = 2.0;
font = 14;
% 定义 Nature 期刊风格的颜色方案
nature_colors = [
    0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB


    0.5  0.294  0.816;  % #7F4BB1
    0.8   0.2    0.067;  % #CC3311
    0    0.467  0.741;  % #0077BB 
    0.984 0.835  0.667;  % #FBD5B4
    0    0.6    0.533;  % #009988
    0.902 0.353  0.314;  % #E78951
];

subplot(211), hold on, ylabel('v_p^{L_3} (mV)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), axis([0 t_sim -20 20])
title('Normal','fontsize',font)
plot(t, sum(vp3(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(vp3(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(vp3(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(vp3(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(vp3(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(vp3(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(vp3(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(vp3(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(vp3(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(vp3(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca,'fontsize',font)


%% TEST COND. ANOMALA - patologia Schizofrenia, modalit� recall
clc

train_flag=0 ;
load_sinapsi
t_sim=0.8;
dt=0.0001;
t=0:dt:t_sim;


A_L2L2=A_L2L2*0.68;
A_L3L3=A_L3L3*0.68;




coeff_Cep=1;
coeff_Cpe=1;
coeff_Csp=1;%0.5
coeff_Cps=1;
 coeff_Cfs=1;
 coeff_Cfp=1;
coeff_Cpf=1;
 coeff_Cff=1;
 % Wp_L2L1=0.6*Wp_L2L1;
% Wp_L1WM=1*Wp_L1WM;
% Wp_WML1=1*Wp_WML1;
Wp_L2L1=0.4*Wp_L2L1;%耦合会显著变小
Wp_L3L2=1*Wp_L3L2;%0.1
Wp_L2L3=1*Wp_L2L3;

INPUT_WM=zeros(numero_colonne,8001);
buff=zeros(numero_colonne, round(0.05/dt));
pos=find(corrupt_pattern(all_patterns(:,5))==1);
buff(pos,:)=1;
INPUT_WM(:,51:550)=buff;

reteWM_sim_pat,
IN0=INPUT_WM*125+np0;
save ('figure14.mat')
line = 2.0;
font = 14;
% 定义 Nature 期刊风格的颜色方案
nature_colors = [
    0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB


    0.5  0.294  0.816;  % #7F4BB1
    0.8   0.2    0.067;  % #CC3311
    0    0.467  0.741;  % #0077BB 
    0.984 0.835  0.667;  % #FBD5B4
    0    0.6    0.533;  % #009988
    0.902 0.353  0.314;  % #E78951
];

subplot(212), hold on, ylabel('v_p^{L_3} (mV)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), xlabel('time (s)'), axis([0 t_sim -20 20])
title('Pathway lesion','fontsize',font)
plot(t, sum(vp3(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(vp3(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(vp3(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(vp3(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(vp3(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(vp3(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(vp3(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(vp3(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(vp3(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(vp3(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca,'fontsize',font)
legend('Object 1','Object 2','Object 3','Object 4','Object 5','Object 6','Object 7', 'Object 8','Object 9', 'Object 10')%, 'obj8','obj9'