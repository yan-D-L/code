function Asymmetric_Hebbian_Rule()
    % 参数设置
    N = 2; % 神经元数量
    tau = 10; % 时间常数
    A_plus = 0.1; % 正性权重增量
    A_minus = -0.1; % 负性权重增量
    t_max = 100; % 仿真时间长度
    dt = 0.1; % 时间步长
    synapse_weights = ones(N, N); % 初始化突触权重为 1

    % 时间向量
    t = 0:dt:t_max;

    % 初始化发放率记录
    firing_rates = zeros(N, length(t));

    % 仿真过程
    for i = 1:1:1001
        % 随机生成神经元群体的发放率
        for n = 1:N
            if rand < 0.1 % 假设每个神经元有10%的概率发放
                firing_rates(n, i) = 1;
            else
                firing_rates(n, i) = 0;
            end
        end

        % 计算平均发放率
        mean_firing_rate1 = mean(firing_rates(1, :));
        mean_firing_rate2 = mean(firing_rates(2, :));

        % 更新突触权重
        % 非对称赫布规则：如果第一个神经元的平均发放率高于第二个，则增加权重，反之减少
        synapse_weights(1, 2) = synapse_weights(1, 2) + A_plus * (mean_firing_rate1 - mean_firing_rate2) * exp(-((t(i) - t(i-1)) / tau));
        synapse_weights(2, 1) = synapse_weights(2, 1) + A_minus * (mean_firing_rate2 - mean_firing_rate1) * exp(-((t(i) - t(i-1)) / tau));
    end

    % 绘制结果
    figure;
    plot(t, synapse_weights);
    xlabel('Time (ms)');
    ylabel('Synaptic Weight');
    title('Asymmetric Hebbian Rule with Mean Firing Rate');
end