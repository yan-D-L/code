
% Lo script richiede che siano gi� costruiti i pattern; si faccia uso della prima sezione
% di MAIN a tal scopo.
%% test rete intera (recall di sequenze) + Working Memory 
clc
MAIN


train_flag=0; 
load_sinapsi

 t_sim=1.8;%1.98
dt=0.0001;
t=0:dt:t_sim;

A_L2L2=A_L2L2*1.4;%2/3 0.68  0.48
 A_L3L3=A_L3L3*1.4;


% if SET_PATT==3
%     Wp_L1L1=Wp_L1L1*0.75;
% end
%联想时输入两个就行，第一个输入3第二个输入1  9751:10250 只能训练顺序2,4,7,6,1,8,5,10,3,9  1.98s
INPUT_WM=zeros(numero_colonne,length(t));
% buff=zeros(numero_colonne, round(0.05/dt));%输入500时间步
% pos=find(corrupt_pattern(sum(all_patterns(:, [2,4,7]),2))==1);
% pos=find(corrupt_pattern(all_patterns(:,2))==1);
% buff(pos,:)=1;
% INPUT_WM(:,51:550)=buff;
INPUT_WM([30,19:24],51:550)=1;
% buff=zeros(numero_colonne, round(0.05/dt));
% pos=find(corrupt_pattern(all_patterns(:,3))==1);
% buff(pos,:)=1;
INPUT_WM([136,130:135],10751:11250)=1;
% buff=zeros(numero_colonne, round(0.06/dt));
% pos=find(corrupt_pattern(all_patterns(:,2))==1);
% buff(pos,:)=1;
% INPUT_WM(:,15951:16550)=buff;
% buff=zeros(numero_colonne, round(0.05/dt));
% pos=find(corrupt_pattern(all_patterns(:,4))==1);
% buff(pos,:)=1;
% INPUT_WM(:,24051:24550)=buff;
newquanzhong
retenewquanzhong, IN0=INPUT_WM*230+np0;
% pjv6=sum(vp1(pos1,:))/size(pos1,2)+sum(vp1(pos2,:))/size(pos2,2)+sum(vp1(pos3,:))/size(pos3,2)+sum(vp1(pos4,:))/size(pos4,2)+sum(vp1(pos5,:))/size(pos5,2)+sum(vp1(pos6,:))/size(pos6,2)+sum(vp1(pos7,:))/size(pos7,2)+sum(vp1(pos8,:))/size(pos8,2)+sum(vp1(pos9,:))/size(pos9,2)+sum(vp1(pos10,:))/size(pos10,2);
% pjv6= vp3(:, 1050:8036);
% pjz6= zp3(:, 1050:8036);
% 初始化
% 初始化
threshold = 3.5; % 设定阈值
time_intervals = cell(10, 1); % 用于保存每个 posi 的时间段
max_values = cell(10, 1);     % 用于保存每个 posi 的最大值
rise_times = cell(10, 1);     % 保存上升时间（从0.2到阈值的上升时间）


save('figure6.mat' )

line = 2.0;
font = 14;
% 定义 Nature 期刊风格的颜色方案
nature_colors = [
    0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB


    0.5  0.294  0.816;  % #7F4BB1
    0.8   0.2    0.067;  % #CC3311
    0    0.467  0.741;  % #0077BB 
    0.984 0.835  0.667;  % #FBD5B4
    0    0.6    0.533;  % #009988
    0.902 0.353  0.314;  % #E78951
];

figure;

% 第一个子图
subplot(511), hold on, ylabel('Input'), axis([0 t_sim -30 140])
plot(t, sum(IN0(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(IN0(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(IN0(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(IN0(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(IN0(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(IN0(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(IN0(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(IN0(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(IN0(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(IN0(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第二个子图
subplot(512), hold on, ylabel('z_p^{L_0} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), axis([0 t_sim 0 2])
plot(t, sum(zp0(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp0(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp0(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp0(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp0(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp0(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp0(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp0(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp0(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp0(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第三个子图
subplot(513), hold on, ylabel('z_p^{L_1} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), axis([0 t_sim 0 2])
plot(t, sum(zp1(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp1(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp1(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp1(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp1(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp1(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp1(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp1(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp1(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp1(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第四个子图
subplot(514), hold on, ylabel('z_p^{L_2} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), axis([0 t_sim 0 2])
plot(t, sum(zp2(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp2(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp2(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp2(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp2(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp2(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp2(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp2(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp2(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp2(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第五个子图
subplot(515), hold on, ylabel('z_p^{L_3} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), xlabel('time (s)'), axis([0 t_sim 0 2])
plot(t, sum(zp3(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp3(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp3(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp3(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp3(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp3(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp3(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp3(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp3(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp3(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% 添加 y=3.5 的肉棕色虚线
% plot([0, t_sim], [3.5, 3.5], '--', 'Color', [0.6, 0.4, 0.2], 'lineWidth', line)
set(gca, 'fontsize', font)
legend('Object 1','Object 2','Object 3','Object 4','Object 5','Object 6','Object 7', 'Object 8','Object 9', 'Object 10')%, 'obj8','obj9'