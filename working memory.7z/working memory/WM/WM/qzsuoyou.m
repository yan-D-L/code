load('sinapsi_SET13.mat');  % 加载包含 A_L2L2 和 Wp_L2L1 的文件
Wp_L2L1= load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L2L1').Wp_L2L1; 
Wp_L1WM = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L1WM').Wp_L1WM; 
Wp_L2L3= load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L2L3').Wp_L2L3; 
obj1_groups = {[19:24], [34:39], [49:52]};    
obj3_groups = {[8:12], [25:29], [40:42], [53:55]};
obj4_groups = {[13:15], [43:45], [56:57], [145:150], [153:154]};

% 提取每个物体的所有索引
obj1_idx = unique([obj1_groups{:}]);
obj3_idx = unique([obj3_groups{:}]);
obj4_idx = unique([obj4_groups{:}]);

% 合并1、3、4物体的所有索引
all_obj_idx = unique([obj1_idx, obj3_idx, obj4_idx]);

% 为Wp_L1WM创建仅包含1、3、4位置的权重矩阵
Wp_L1WM_selected = zeros(size(Wp_L1WM));
% 行和列都只保留属于1、3、4物体的索引
row_mask = ismember(1:size(Wp_L1WM,1), all_obj_idx);
col_mask = ismember(1:size(Wp_L1WM,2), all_obj_idx);
Wp_L1WM_selected(row_mask, col_mask) = Wp_L1WM(row_mask, col_mask);

% 为Wp_L2L1创建仅包含1、3、4位置的权重矩阵
Wp_L2L1_selected = zeros(size(Wp_L2L1));
row_mask_l2l1 = ismember(1:size(Wp_L2L1,1), all_obj_idx);
col_mask_l2l1 = ismember(1:size(Wp_L2L1,2), all_obj_idx);
Wp_L2L1_selected(row_mask_l2l1, col_mask_l2l1) = Wp_L2L1(row_mask_l2l1, col_mask_l2l1);



axis_range = [1, 165];          
% 2. 统一刻度间隔50，剔除0点（刻度为50,100,150,165），确保0不显示
fixed_interval = 50;             
fixed_xticks = [fixed_interval:fixed_interval:axis_range(2)];  % 横轴刻度：50,100,150,165
fixed_yticks = [fixed_interval:fixed_interval:axis_range(2)];  % 纵轴刻度（与横轴完全一致）


% -------------------------- 4. 创建子图（0点显示+统一间隔） --------------------------
figure('Position', [100, 100, 1200, 800]);
colormap parula;


% -------------------------- 子图1：Wp_L1WM_selected --------------------------
subplot(2, 2, 1);
% 关键：用'XData'/'YData'指定矩阵边缘坐标，让0点对应左上角边缘
imagesc(Wp_L1WM_selected, 'XData', [0, 165], 'YData', [0, 165]);
% 强制统一刻度（包含0点）
xlim(axis_range);
ylim(axis_range);
xticks(fixed_xticks);
yticks(fixed_yticks);
% 颜色条（间距0.005，无标题）
cb1 = colorbar('Position', [gca().Position(1) + gca().Position(3) + 0.005, ...
                            gca().Position(2), 0.02, gca().Position(4)]);
% 标题与轴标签（下标正确）
title('L_0 → L_1 (Only Objects 1, 3, 4)', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
xlabel('Layer L_1', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
ylabel('Layer L_0', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
set(gca, 'YDir', 'normal');  % Y轴从上到下为0→165（匹配边缘对齐）
axis square;  % 方形显示，确保横纵间隔视觉一致


% -------------------------- 子图2：Wp_L2L1_selected --------------------------
subplot(2, 2, 2);
imagesc(Wp_L2L1_selected, 'XData', [0, 165], 'YData', [0, 165]);  % 边缘对齐
xlim(axis_range);
ylim(axis_range);
xticks(fixed_xticks);
yticks(fixed_yticks);
cb2 = colorbar('Position', [gca().Position(1) + gca().Position(3) + 0.005, ...
                            gca().Position(2), 0.02, gca().Position(4)]);
title('L_1 → L_2 (Only Objects 1, 3, 4)', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
xlabel('Layer L_2', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
ylabel('Layer L_1',  ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
set(gca, 'YDir', 'normal');
axis square;


% -------------------------- 子图3：Wp_L2L3 --------------------------
subplot(2, 2, 3);
imagesc(Wp_L2L3, 'XData', [0, 165], 'YData', [0, 165]);  % 边缘对齐
xlim(axis_range);
ylim(axis_range);
xticks(fixed_xticks);
yticks(fixed_yticks);
cb3 = colorbar('Position', [gca().Position(1) + gca().Position(3) + 0.005, ...
                            gca().Position(2), 0.02, gca().Position(4)]);
title('L_3 → L_2 (All Objects)', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
xlabel('Layer L_2', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
ylabel('Layer L_3', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
set(gca, 'YDir', 'normal');
axis square;
hold on 
nature_colors = [
    0.878 0.78  0.941 ;  % 1:浅紫粉-Object1
    0.933 0.467  0.2   ;  % 2:橙红-Object2
    0.2   0.667  0.933 ;  % 3:亮蓝-Object3
    0.733 0.733  0.733 ;  % 4:浅灰-Object4
    0.5   0.294  0.816 ;  % 5:深紫-Object5
    0.8   0.2    0.067 ;  % 6:暗红-Object6
    0     0.467  0.741 ;  % 7:深蓝-Object7
    0.984 0.835  0.667 ;  % 8:浅橙-Object8
    0     0.6    0.533 ;  % 9:青绿-Object9
    0.902 0.353  0.314 ;  % 10:橙粉-Object10
];
% 初始化句柄数组存储圆点标记
marker_handles = gobjects(1, 10);

for i = 1:10
    % 绘制隐藏的圆点（仅用于图例，不显示在图中）
    marker_handles(i) = plot(NaN, NaN, 'o', ...  % NaN确保点不显示在图中
                            'MarkerSize', 8, ...  % 圆点大小
                            'MarkerFaceColor', nature_colors(i,:), ...  % 填充色
                            'MarkerEdgeColor', 'none', ...  % 无边框
                            'LineWidth', 1.2);  % 线条宽度（不影响圆点）
end

% -------------------------- 5. 创建图例（圆点标记+黑色文字） --------------------------
leg = legend(marker_handles, ...  % 关联圆点标记句柄
             'Object 1', 'Object 2', 'Object 3', 'Object 4', 'Object 5', ...
             'Object 6', 'Object 7', 'Object 8', 'Object 9', 'Object 10', ...
             'Location', 'best', ...
             'NumColumns', 2, ...  % 2列布局
             'FontSize', 10, ...
             'Color', 'white', ...  % 白色背景
             'EdgeColor', 'none', ...
       'FontName', 'Arial', ...  % 图例字体也设为Arial
       'FontSize', 12);  % 无边框

% 强制图例文字为黑色并加粗
text_objs = findobj(leg, 'Type', 'Text');
set(text_objs, ...
    'Color', [0 0 0], ...        % 纯黑色
    'FontWeight', 'bold', ...    % 加粗
    'FontName', 'Arial');        % 无衬线字体

hold off;
    