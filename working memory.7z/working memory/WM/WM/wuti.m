clear
clc
close all




%%
disp("choose the pattern with variable dimensions (number 2)")
N=11;
M=15; 
numero_colonne=N*M;

P=zeros(M*N,1);
all_patterns=zeros(N*M,10);
    figure
    %P1
    P1=P(:);
    pos1=[19:24 34:39 49:52];
    P1(pos1)=1;
    all_patterns(:,1)=P1;
   
    P2=P(:);
    pos2=[  66:71 81:82 96:97 111:116];
    P2(pos2)=1;
    all_patterns(:,2)=P2;
    
    P3=P(:);
    pos3=[8:12 25:29 40:42 53:55];
    P3(pos3)=1;
    all_patterns(:,3)=P3;
    
    P4=P(:);
    pos4=[13:15 43:45 56:57 145:150 153:154];
    P4(pos4)=1;
    all_patterns(:,4)=P4;
    
    P5=P(:);
    pos5=[61:65 76:78 91:93 106:110 ];
    P5(pos5)=1;
    all_patterns(:,5)=P5;
    
    %P6
    P6=P(:);
    pos6=[98:103 130:135 128:129 151:152];
    P6(pos6)=1;
    all_patterns(:,6)=P6;
    
    %P7
    P7=P(:);
    pos7=[58:60 72:75 84:90 104:105];
    P7(pos7)=1;
    all_patterns(:,7)=P7;
    
    %P8
    P8=P(:);
    pos8=[79:80 117:120 137:138 158:165 ];
    P8(pos8)=1;
    all_patterns(:,8)=P8;
    
    %P9
    P9=P(:);
    pos9=[94:95 121:127 140:144 155:156];
    P9(pos9)=1;
    all_patterns(:,9)=P9;
    


    P10=P(:);
    pos10=[1:7 16:18 31:33 46:48];
    P10(pos10)=1;
    all_patterns(:,10)=P10;

    % ----------------------颜色合并图像显示-------------------------
% 定义颜色表
nature_colors = [
    0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB


    0.5  0.294  0.816;  % #7F4BB1
    0.8   0.2    0.067;  % #CC3311
    0    0.467  0.741;  % #0077BB 
    0.984 0.835  0.667;  % #FBD5B4
    0    0.6    0.533;  % #009988
    0.902 0.353  0.314;  % #E78951
   
 
   
];

% 初始化 RGB 图像为全 0
% 初始化 RGB 图像
% 初始化 RGB 图像为白色背景
RGB = ones(N, M, 3);  % 每个像素初始为 [1, 1, 1]（白色）

alpha = 1;  % 透明度



for i = 1:10
    pattern_img = vecToIm(all_patterns(:, i), N, M);
    mask = double(pattern_img > 0);

    for c = 1:3
        RGB(:,:,c) = RGB(:,:,c) - alpha * mask .* (1 - nature_colors(i, c));
    end
end

RGB = min(max(RGB, 0), 1);

overlap_mask = zeros(N, M);  % 注意维度是 N 行 × M 列
for i = 1:10
    pattern_img = vecToIm(all_patterns(:, i), N, M);  % 注意顺序 N, M
    overlap_mask = overlap_mask + double(pattern_img > 0);
end
overlap_mask = overlap_mask > 1;  % 重叠区域

% -------- 找边界 --------
boundaries = bwboundaries(overlap_mask, 'noholes');

border_colors = parula(10); % 或自定义 10 个颜色

% 显示 RGB 图像
figure;
image(RGB);
axis image off;
title('All 10 orthogonal objects');
hold on;

% 对每个对象计算其与其他对象的重叠区域
for i = 1:10
    % 当前对象
    pattern_i = vecToIm(all_patterns(:, i), N, M) > 0;

    % 所有其他对象的联合区域
    other_union = false(N, M);
    for j = 1:10
        if j ~= i
            other_union = other_union | (vecToIm(all_patterns(:, j), N, M) > 0);
        end
    end

    % 计算重叠区域：当前对象与其他对象交集
    overlap_i = pattern_i & other_union;

    % 找边界
    boundaries = bwboundaries(overlap_i, 'noholes');

    % 画边框
    for k = 1:length(boundaries)
        boundary = boundaries{k};
        plot(boundary(:,2), boundary(:,1), 'Color', border_colors(i,:), 'LineWidth', 2);
    end
end
% ---------------- 添加图例 ----------------
% 创建颜色标签句柄
legend_handles = gobjects(10, 1);  % 初始化图例句柄数组
legend_labels = cell(10, 1);       % 初始化标签

for i = 1:10
    % 创建不可见的小色块用于图例
    legend_handles(i) = plot(nan, nan, 's', ...
        'MarkerFaceColor', nature_colors(i,:), ...
        'MarkerEdgeColor', nature_colors(i,:), ...
        'MarkerSize', 10);
    
    legend_labels{i} = sprintf('Object %d', i);
end
x = [0.5, M+0.5, M+0.5, 0.5, 0.5];%最外面的黑色边框
y = [0.5, 0.5, N+0.5, N+0.5, 0.5];
plot(x, y, 'k', 'LineWidth', 1);
% 添加图例
legend(legend_handles, legend_labels, 'Location', 'eastoutside');

% % 显示图像
% figure;
% image(RGB_with_border);
% axis image off;
% title('All 10 objects on white background');
% hold on 
% 显示结果
% figure('Position', [600 600 1000 1000]) % 调整窗口大小;
% imshow(RGB_with_border);
% title('Objects with overlap highlighted by red border');


