% 正确加载cell数组中的元素
% 先加载整个cell数组，再提取{1,1}元素
load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L1WM_store');
Wp_L1WM_store_11 = Wp_L1WM_store{1,1};

% 同理修正第二个cell数组的加载方式
load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L3L2_store');
Wp_L3L2_store_14 = Wp_L3L2_store{1,4};

% 加载其他矩阵
Wp_L3L2 = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L3L2').Wp_L3L2;
Wp_L1WM = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L1WM').Wp_L1WM;
Wp_L2L3 = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\sinapsi_SET13.mat', 'Wp_L2L3').Wp_L2L3;
% 定义颜色
color_obj1 = [0.878, 0.78, 0.941];   % #E0C5F2
color_obj4 = [ 0.2   0.667  0.933];  % #BBBBBB
color_both = [0.733 0.733  0.733];  % #BBBBBB];  % #967EA6
% 定义需要显示的标签范围
ranges = [19:24, 34:39, 49:52, 8:12, 25:29, 40:42, 53:55, 13:15, 43:45, 56:57, 145:150, 153:154];
% 转换为升序以便处理
display_indices = sort(ranges);

% 为Wp_L1WM创建掩码，只显示指定范围
mask_L1WM = false(size(Wp_L1WM));
for i = 1:length(display_indices)
    if display_indices(i) <= size(mask_L1WM, 1) && display_indices(i) <= size(mask_L1WM, 2)
        mask_L1WM(display_indices(i), :) = true;
        mask_L1WM(:, display_indices(i)) = true;
    end
end
Wp_L1WM_masked = Wp_L1WM .* mask_L1WM;

% 为Wp_L2L1创建掩码，只显示指定范围
mask_L3L2 = false(size(Wp_L3L2));
for i = 1:length(display_indices)
    if display_indices(i) <= size(mask_L3L2, 1) && display_indices(i) <= size(mask_L3L2, 2)
        mask_L3L2(display_indices(i), :) = true;
        mask_L3L2(:, display_indices(i)) = true;
    end
end
Wp_L3L2_masked = Wp_L3L2 .* mask_L3L2;

% 为Wp_L2L1_store_14创建掩码，只显示指定范围
mask_L3L2_store_14 = false(size(Wp_L3L2_store_14));
for i = 1:length(display_indices)
    if display_indices(i) <= size(mask_L3L2_store_14, 1) && display_indices(i) <= size(mask_L3L2_store_14, 2)
        mask_L3L2_store_14(display_indices(i), :) = true;
        mask_L3L2_store_14(:, display_indices(i)) = true;
    end
end
Wp_L3L2_store_14_masked = Wp_L3L2_store_14 .* mask_L3L2_store_14;

% 创建图形窗口
figure('Position', [100 100 1200 800]);

% 绘制第一个权重矩阵
% 绘制第四个权重矩阵（使用掩码版本）
subplot(2,2, 1);
imagesc(Wp_L1WM_masked);
colorbar;
title('W_pL1L0 (object 1、3、4)');
axis square;
set(gca, 'YDir', 'normal');

subplot(2,2, 2);
imagesc(Wp_L3L2_masked);
colorbar;
title('W_pL2L1 (object 1、3、4)');
axis square;
set(gca, 'YDir', 'normal');




% 绘制第二个权重矩阵（使用掩码版本）
subplot(2,2, 3);
imagesc(Wp_L2L3);
colorbar;
title('W_pL2L3(all 10 objects)');
axis square;
set(gca, 'YDir', 'normal');


% % 绘制第三个权重矩阵（使用掩码版本）
% subplot(2,3, 4);
% imagesc(Wp_L1WM_store_11);
% colorbar;
% title('W_pL1L0(Training)(object 1)');
% axis square;
% set(gca, 'YDir', 'normal');
% 
% % 绘制第五个权重矩阵
% subplot(2,3, 5);
% imagesc(Wp_L3L2_store_14_masked);
% colorbar;
% title('W_pL2L1(Training) (object 1、3、4)');
% axis square;
% set(gca, 'YDir', 'normal');
% 添加图例
hold on;
h1 = plot(NaN, NaN, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color_obj1, 'MarkerEdgeColor', 'none');
h2 = plot(NaN, NaN, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color_obj4, 'MarkerEdgeColor', 'none');
h3 = plot(NaN, NaN, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color_both, 'MarkerEdgeColor', 'none');
legend([h1, h2, h3], 'Object 1', 'Object 3', 'Object 4', ...
       'Location', 'best', 'Color', 'white', 'EdgeColor', 'none');
% sgtitle('权重矩阵可视化');
tight_layout;