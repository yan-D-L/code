function [corrupted_input]=corrupt_pattern(pattern)
% corrompe un pattern selezionato, ponendo il 30% dei suoi pixel a 0.

index=find(pattern==1);
corrupted_input=pattern;
Conta=sum(pattern); %numero di pixel a 1 pre-corruzione.
rng('shuffle')
while sum(corrupted_input)>0.5*Conta
    n=randi(length(index),1,1);%返回一个由介于 1 和length(index)之间的伪随机整数组成的 1×1数组。
    pos=index(n);
    corrupted_input(pos)=0;%当模式输入大于0.7时，随意将1的位置变为0，直至输入小于0.7
end

end

%输入破损的模式，0.7倍，一共9种模式