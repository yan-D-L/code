% 加载数据
vp3 = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\figure6.mat', 'vp3').vp3;  % 假设变量名为 'vp3'

% 创建新矩阵
pjvp = [];

% 定义行分组
row_groups = {
    79:80, 117:120, 137:138, 158:165;   % 组1
    13:15, 43:45, 56:57, 145:150, 153:154;  % 组2
    58:60, 72:75, 84:90, 104:105;  % 组3
    98:103, 130:135, 128:129, 151:152; % 组4
};

% 定义列分组
col_groups = {
    1:945;   % 列1
    946:1184; % 列2
    1185:1422; % 列3
    1423:1665; % 列4
};


% 直接对应每个行组与列组
for idx = 1:min(length(row_groups), length(col_groups))
    rows = row_groups{idx};  % 获取当前行范围
    cols = col_groups{idx};  % 获取当前列范围

    % 获取子矩阵
    sub_matrix = vp3(rows, cols);

    % 调试输出，检查矩阵的大小
    disp(['Processing row group ', num2str(idx), ', col group ', num2str(idx)]);
    disp(['Size of sub_matrix: ', num2str(size(sub_matrix))]);

    % 求按列均值
    mean_vals = mean(sub_matrix, 1);  % 按列求均值

    % 检查维度
    disp(['Size of mean_vals: ', num2str(size(mean_vals))]);

    % 如果是第一次迭代，直接赋值
    if isempty(pjvp)
        pjvp = mean_vals;  % 第一次赋值
    else
        % 确保列数一致再拼接
        if size(pjvp, 2) == length(mean_vals)
            pjvp = [pjvp, mean_vals];  % 将均值拼接到新矩阵
        else
            error('The number of columns in the current matrix does not match the existing matrix.');
        end
    end
end

% 显示新矩阵的大小
disp('Size of new matrix:');
disp(size(pjvp));  % 输出新矩阵的尺寸