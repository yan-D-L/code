clc; clear;

% 参数设置
param_set = [0.88, 0.9, 0.92]; % 示例参数 thresh_low 值
num_tasks = length(param_set);

% 启动多个 MATLAB 实例并行运行
for i = 1:num_tasks
    % 为每个任务生成不同的参数
    thresh_low = param_set(i);
    thresh_up = 0.8; % 例如，固定一个参数

    % 保存当前任务的参数到文件
    param_file = sprintf('params_task_%d.mat', i);
    save(param_file, 'thresh_low', 'thresh_up');

    % 使用 system 命令启动新的 MATLAB 实例并传递参数文件
    command = sprintf('matlab -batch "run(''L2_train_phase2.m'', ''%s'')" &', param_file);
    system(command);
end

disp('所有任务已启动。');