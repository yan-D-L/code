% 加载原始权重矩阵
% load('sinapsi_SET1.mat', 'Wp_L1WM', 'Wp_WML1', 'Wp_L2L1', 'Wp_L3L2', 'Wp_L2L3');

% 定义任务相关神经元索引
idx_color    = [19:24, 79:80, 117:120, 8:12, 25, 13:15, 43:45, 61:65, 76, 98:103, 58:60, 72:74, 66:71, 94:95, 121:124, 1:6];
idx_location = [34:39, 137:138, 158:161, 26:29, 40:41, 56:57, 145:148, 77:78, 91:93, 106, 130:135, 75, 84:88, 111:116, 125:127, 140:142, 7, 16:18, 31:32];
idx_size     = [49:52, 162:165, 42, 53:55, 149:150, 153:154, 107:110, 128:129, 151:152, 89:90, 104:105, 81:82, 96:97, 143:144, 155:156, 33, 46:48];

% 初始化新权重矩阵
Wp_L1WM_new  = zeros(size(Wp_L1WM));
Wp_WML1_new  = zeros(size(Wp_WML1));
Wp_L1L1_new  = zeros(size(Wp_L1L1));
K_L2L2_new  = zeros(size(K_L2L2));
Wp_L2L1_new  = zeros(size(Wp_L2L1));
Wp_L3L2_new  = zeros(size(Wp_L3L2));
Wp_L2L3_new  = zeros(size(Wp_L2L3));

% 判断任务类型（支持多任务）
is_color_task = any(INPUT_WM(30, :));
is_location_task = any(INPUT_WM(136, :));
is_size_task = any(INPUT_WM(157, :));

% 处理多任务情况（分别更新各任务区域，避免跨任务连接）
if is_color_task
    Wp_L1WM_new(idx_color, idx_color) = 3*Wp_L1WM(idx_color, idx_color);
    Wp_WML1_new(idx_color, idx_color) = 3*Wp_WML1(idx_color, idx_color);
    Wp_L1L1_new(idx_color, idx_color) = 3*Wp_L1L1(idx_color, idx_color);
    K_L2L2_new(idx_color, idx_color) = 3*K_L2L2(idx_color, idx_color);
    Wp_L2L1_new(idx_color, idx_color) = 3*Wp_L2L1(idx_color, idx_color);
    Wp_L3L2_new(idx_color, idx_color) = 3*Wp_L3L2(idx_color, idx_color);
    Wp_L2L3_new(idx_color, idx_color) = 1.9*Wp_L2L3(idx_color, idx_color);
end

if is_location_task
    Wp_L1WM_new(idx_location, idx_location) = 3*Wp_L1WM(idx_location, idx_location);
    Wp_WML1_new(idx_location, idx_location) = 3*Wp_WML1(idx_location, idx_location);
    Wp_L1L1_new(idx_location, idx_location) = 3*Wp_L1L1(idx_location, idx_location);
    K_L2L2_new(idx_location, idx_location) = 3*K_L2L2(idx_location, idx_location);
    Wp_L2L1_new(idx_location, idx_location) = 3*Wp_L2L1(idx_location, idx_location);
    Wp_L3L2_new(idx_location, idx_location) = 3*Wp_L3L2(idx_location, idx_location);
    Wp_L2L3_new(idx_location, idx_location) = 1.9*Wp_L2L3(idx_location, idx_location);
end

if is_size_task
    Wp_L1WM_new(idx_size, idx_size) = 3*Wp_L1WM(idx_size, idx_size);
    Wp_WML1_new(idx_size, idx_size) = 3*Wp_WML1(idx_size, idx_size);
    Wp_L1L1_new(idx_size, idx_size) = 3*Wp_L1L1(idx_size, idx_size);
    K_L2L2_new(idx_size, idx_size) = 3*K_L2L2(idx_size, idx_size);
    Wp_L2L1_new(idx_size, idx_size) = 3*Wp_L2L1(idx_size, idx_size);
    Wp_L3L2_new(idx_size, idx_size) = 3*Wp_L3L2(idx_size, idx_size);
    Wp_L2L3_new(idx_size, idx_size) = 1.9*Wp_L2L3(idx_size, idx_size);
end

K_L3L3_new = K_L2L2_new;
% 特定任务 → Wp_L1WM 特定区域加5
% switch task_type
%     case 'color'
%         % Wp_L1WM_new(19:24, 30) = Wp_L1WM_new(19:24, 30) + 100;
%     case 'location'
%         % Wp_L1WM_new(34:39, 136) = Wp_L1WM_new(34:39, 136) + 100;
%     case 'size'
%         Wp_L1WM_new(49:52, 157) = Wp_L1WM_new(49:52, 157) + 100;
% end
