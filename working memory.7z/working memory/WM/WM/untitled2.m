load('sinapsi_SET12.mat');  % 加载数据，Wp_L1L1为权重矩阵

% 定义子区间（对应权重矩阵中的索引数值）
obj1_groups = {[19:24], [34:39], [49:52]};  % 属于Object 1的索引数值
obj4_groups = {[13:15], [43:45], [49:52], [145:150]};  % 属于Object 4的索引数值

% 提取所有涉及的索引数值（权重矩阵中的行/列数值）
obj1_indices = unique([obj1_groups{:}]);  % Object 1的索引数值集合
obj4_indices = unique([obj4_groups{:}]);  % Object 4的索引数值集合
all_indices = unique([obj1_indices, obj4_indices]);  % 所有相关索引数值

% 权重矩阵操作（仅保留相关索引对应的数值）
Wp_selected = zeros(size(Wp_L1L1));
Wp_selected(all_indices, all_indices) = Wp_L1L1(all_indices, all_indices);

% 定义颜色
color_obj1 = [0.878, 0.78, 0.941];   % #E0C5F2（Object 1）
color_obj4 = [0.733, 0.733, 0.733];  % #BBBBBB（Object 4）
color_both = [0.588, 0.494, 0.651];  % #967EA6（重叠部分）

% 获取权重矩阵的维度（对应X/Y轴的数值范围）
[rows, cols] = size(Wp_selected);  % rows=Y轴数值范围（行索引），cols=X轴数值范围（列索引）

% 创建图形
figure('Position', [100, 100, 1000, 900]);

% 绘制权重矩阵（主图）
main_ax = axes('Position', [0.15, 0.15, 0.7, 0.7]);
imagesc(Wp_selected);  % 此时X轴显示列索引数值，Y轴显示行索引数值
colorbar;
xlabel('L1 (Output layer index)');  % X轴：权重矩阵的列索引数值
ylabel('L1 (Input layer index)');   % Y轴：权重矩阵的行索引数值
title('Weight connections (X/Y axes correspond to weight indices)');
set(main_ax, 'YDir', 'normal');  % Y轴索引数值从上到下递增（与矩阵行索引一致）
hold on;

% ==== X轴颜色条（对应权重矩阵的列索引数值）====
% 位置：主图正下方，宽度与主图一致，高度适中
x_color_ax = axes('Position', [0.15, 0.08, 0.7, 0.04]);
axis(x_color_ax, 'off');
hold(x_color_ax, 'on');
xlim(x_color_ax, [1, cols]);  % X轴范围严格对应权重矩阵的列索引数值（1到cols）
ylim(x_color_ax, [0, 1]);
box(x_color_ax, 'on');  % 边框用于定位

% 绘制X轴颜色条（仅标记权重矩阵列索引中属于obj1/obj4的数值）
% 1. 先标记重叠部分（优先级最高）
overlap_indices = intersect(obj1_indices, obj4_indices);  % 重叠的索引数值
for idx = overlap_indices
    if idx >= 1 && idx <= cols  % 确保索引在权重矩阵列范围内
        % 每个颜色块严格对应一个列索引数值：左边界=idx-0.5，右边界=idx+0.5
        rectangle(x_color_ax, 'Position', [idx-0.5, 0, 1, 1], ...
                  'FaceColor', color_both, 'EdgeColor', 'none');
    end
end

% 2. 标记仅属于Object 1的索引数值
only_obj1 = setdiff(obj1_indices, overlap_indices);
for idx = only_obj1
    if idx >= 1 && idx <= cols
        rectangle(x_color_ax, 'Position', [idx-0.5, 0, 1, 1], ...
                  'FaceColor', color_obj1, 'EdgeColor', 'none');
    end
end

% 3. 标记仅属于Object 4的索引数值
only_obj4 = setdiff(obj4_indices, overlap_indices);
for idx = only_obj4
    if idx >= 1 && idx <= cols
        rectangle(x_color_ax, 'Position', [idx-0.5, 0, 1, 1], ...
                  'FaceColor', color_obj4, 'EdgeColor', 'none');
    end
end

% ==== Y轴颜色条（对应权重矩阵的行索引数值）====
% 位置：主图左侧，高度与主图一致，宽度适中
y_color_ax = axes('Position', [0.08, 0.15, 0.04, 0.7]);
axis(y_color_ax, 'off');
hold(y_color_ax, 'on');
xlim(y_color_ax, [0, 1]);
ylim(y_color_ax, [1, rows]);  % Y轴范围严格对应权重矩阵的行索引数值（1到rows）
set(y_color_ax, 'YDir', 'normal');  % 行索引数值从上到下递增
box(y_color_ax, 'on');

% 绘制Y轴颜色条（仅标记权重矩阵行索引中属于obj1/obj4的数值）
for idx = overlap_indices
    if idx >= 1 && idx <= rows  % 确保索引在权重矩阵行范围内
        rectangle(y_color_ax, 'Position', [0, idx-0.5, 1, 1], ...
                  'FaceColor', color_both, 'EdgeColor', 'none');
    end
end

for idx = only_obj1
    if idx >= 1 && idx <= rows
        rectangle(y_color_ax, 'Position', [0, idx-0.5, 1, 1], ...
                  'FaceColor', color_obj1, 'EdgeColor', 'none');
    end
end

for idx = only_obj4
    if idx >= 1 && idx <= rows
        rectangle(y_color_ax, 'Position', [0, idx-0.5, 1, 1], ...
                  'FaceColor', color_obj4, 'EdgeColor', 'none');
    end
end

% 添加图例
hold(main_ax, 'on');
h1 = plot(NaN, NaN, 's', 'MarkerSize', 12, 'MarkerFaceColor', color_obj1);
h2 = plot(NaN, NaN, 's', 'MarkerSize', 12, 'MarkerFaceColor', color_obj4);
h3 = plot(NaN, NaN, 's', 'MarkerSize', 12, 'MarkerFaceColor', color_both);
legend([h1, h2, h3], 'Object 1 (indices)', 'Object 4 (indices)', 'Object 1+4 (indices)', ...
       'Location', 'northoutside', 'Orientation', 'horizontal');

% 强制X/Y轴刻度与权重索引一致（关键：确保图形坐标=权重数值索引）
set(main_ax, 'XTick', 1:20:cols, 'YTick', 1:20:rows);  % 刻度间隔可调整
set(x_color_ax, 'XTick', get(main_ax, 'XTick'));  % 颜色条刻度与主图一致
set(y_color_ax, 'YTick', get(main_ax, 'YTick'));

drawnow;
