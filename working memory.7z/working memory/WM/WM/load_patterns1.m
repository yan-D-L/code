% WARNING
% Script dipendente da L1_main. Non lanciare il seguente script da solo.

% Creazione pattern di lavoro:
P=zeros(M*N,1);

% SET 1 - Ortogonali, dim fissa (36px)
if SET_PATT==1
    all_patterns=zeros(N*M,10);
    figure
    %P1
    P1=P(:);
    pos1=[1:5 6:10 11:15  ];%121:129  19:24 34:39 49:52
    P1(pos1)=1;%上述对应行都是1
    all_patterns(:,1)=P1;
    subplot(2,5,1)
    imm=vecToIm(P1,N,M);%将P1的1-m行，m+1-2m,,,n-1*m-nm行一共n个，变成m*n维的向量
    imagesc(~imm), hold on, colormap gray, grid on, title('object 1'), axis image
    somma_pattern=imm;%检查每个物体不正交，即值为0或1
    %P2
    P2=P(:);
    pos2=[16:20 21:25 26:30 ];
    P2(pos2)=1;
    all_patterns(:,2)=P2;
    subplot(2,5,2)
    imm=vecToIm(P2,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 2'), axis image
    somma_pattern=somma_pattern+imm;%检查每个物体不正交，即值为0或1
    %P3
    P3=P(:);
    pos3=[31:35 36:40 41:45  ];
    P3(pos3)=1;
    all_patterns(:,3)=P3;
    subplot(2,5,3)
    imm=vecToIm(P3,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 3'), axis image
    somma_pattern=somma_pattern+imm;
    %P4
    P4=P(:);
    pos4=[46:50 51:55 56:60  ];
    P4(pos4)=1;
    all_patterns(:,4)=P4;
    subplot(2,5,4)
    imm=vecToIm(P4,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 4'), axis image
    somma_pattern=somma_pattern+imm;
    %P5
    P5=P(:);
    pos5=[61:65 66:70 71:75  ];
    P5(pos5)=1;
    all_patterns(:,5)=P5;
    subplot(2,5,5)
    imm=vecToIm(P5,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 5'), axis image
    somma_pattern=somma_pattern+imm;
    %P6
    P6=P(:);
    pos6=[76:80 81:85 86:90  ];
    P6(pos6)=1;
    all_patterns(:,6)=P6;
    subplot(2,5,6)
    imm=vecToIm(P6,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 6'), axis image
    somma_pattern=somma_pattern+imm;
    %P7
    P7=P(:);
    pos7=[91:95 96:100 101:105  ];
    P7(pos7)=1;
    all_patterns(:,7)=P7;
    subplot(2,5,7)
    imm=vecToIm(P7,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 7'), axis image
    somma_pattern=somma_pattern+imm;
    %P8
    P8=P(:);
    pos8=[106:110 111:115 116:120  ];
    P8(pos8)=1;
    all_patterns(:,8)=P8;
    subplot(2,5,8)
    imm=vecToIm(P8,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 8'), axis image
    somma_pattern=somma_pattern+imm;
    %P9
    P9=P(:);
    pos9=[121:125 126:130 131:135 ];
    P9(pos9)=1;
    all_patterns(:,9)=P9;
    subplot(2,5,9)
    imm=vecToIm(P9,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 9'), axis image
    somma_pattern=somma_pattern+imm;
    % P10, 
    P10=P(:);
    pos10=[136:140 141:145 146:150 ];% 1:7 16:18 31:33 46:48
    P10(pos10)=1;
    all_patterns(:,10)=P10;
    subplot(2,5,10)
    imm=vecToIm(P10,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 10 (2*)'), axis image
    somma_pattern=somma_pattern+imm;
    
    % figure, imagesc(somma_pattern)
    clear P
    
    % SET 2 - Ortogonali, dim variabile (36 +/- 9 px)
elseif SET_PATT==2
    all_patterns=zeros(N*M,10);
    figure
    %P1
       P1=P(:);
    pos1=[1:5 6:10 11:15  ];%121:129  19:24 34:39 49:52
    P1(pos1)=1;%上述对应行都是1
    all_patterns(:,1)=P1;
    subplot(2,5,1)
    imm=vecToIm(P1,N,M);%将P1的1-m行，m+1-2m,,,n-1*m-nm行一共n个，变成m*n维的向量
    imagesc(~imm), hold on, colormap gray, grid on, title('object 1'), axis image
    somma_pattern=imm;%检查每个物体不正交，即值为0或1
    %P2
    P2=P(:);
    pos2=[16:20 21:25 26:30 ];
    P2(pos2)=1;
    all_patterns(:,2)=P2;
    subplot(2,5,2)
    imm=vecToIm(P2,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 2'), axis image
    somma_pattern=somma_pattern+imm;%检查每个物体不正交，即值为0或1
    %P3
    P3=P(:);
    pos3=[31:35 36:40 41:45  ];
    P3(pos3)=1;
    all_patterns(:,3)=P3;
    subplot(2,5,3)
    imm=vecToIm(P3,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 3'), axis image
    somma_pattern=somma_pattern+imm;
    %P4
    P4=P(:);
    pos4=[1:3 49:50 51:55 56:60  ];
    P4(pos4)=1;
    all_patterns(:,4)=P4;
    subplot(2,5,4)
    imm=vecToIm(P4,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 4'), axis image
    somma_pattern=somma_pattern+imm;
    %P5
    P5=P(:);
    pos5=[61:65 66:70 71:75  ];
    P5(pos5)=1;
    all_patterns(:,5)=P5;
    subplot(2,5,5)
    imm=vecToIm(P5,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 5'), axis image
    somma_pattern=somma_pattern+imm;
    %P6
    P6=P(:);
    pos6=[76:80 81:85 86:90  ];
    P6(pos6)=1;
    all_patterns(:,6)=P6;
    subplot(2,5,6)
    imm=vecToIm(P6,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 6'), axis image
    somma_pattern=somma_pattern+imm;
    %P7
    P7=P(:);
    pos7=[91:95 96:100 101:105  ];
    P7(pos7)=1;
    all_patterns(:,7)=P7;
    subplot(2,5,7)
    imm=vecToIm(P7,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 7'), axis image
    somma_pattern=somma_pattern+imm;
    %P8
    P8=P(:);
    pos8=[43:45 106:110 111:115 116:117  ];
    P8(pos8)=1;
    all_patterns(:,8)=P8;
    subplot(2,5,8)
    imm=vecToIm(P8,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 8'), axis image
    somma_pattern=somma_pattern+imm;
    %P9
    P9=P(:);
    pos9=[121:125 126:130 131:135 ];
    P9(pos9)=1;
    all_patterns(:,9)=P9;
    subplot(2,5,9)
    imm=vecToIm(P9,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 9'), axis image
    somma_pattern=somma_pattern+imm;
    % P10, 
    P10=P(:);
    pos10=[136:140 141:145 146:150 ];% 1:7 16:18 31:33 46:48
    P10(pos10)=1;
    all_patterns(:,10)=P10;
    subplot(2,5,10)
    imm=vecToIm(P10,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 10 (2*)'), axis image
    somma_pattern=somma_pattern+imm;
    
    % Decommentare la riga seguente per visualizzare tutti i pattern insieme e
    % verificare l'eventuale presenza di sovrapposizioni:
    %figure, imagesc(somma_pattern)
    clear P
    
elseif SET_PATT==3
   all_patterns=zeros(N*M,10);
    figure
    %P1
    P1=P(:);
    pos1=[19:24 34:39 49:52  ];%121:129  19:24 34:39 49:52
    P1(pos1)=1;%上述对应行都是1
    all_patterns(:,1)=P1;
    subplot(2,5,1)
    imm=vecToIm(P1,N,M);%将P1的1-m行，m+1-2m,,,n-1*m-nm行一共n个，变成m*n维的向量
    imagesc(~imm), hold on, colormap gray, grid on, title('object 1'), axis image
    somma_pattern=imm;%检查每个物体不正交，即值为0或1
    %P2
    P2=P(:);
    pos2=[79:80 117:120 137:138 158:165 ];
    P2(pos2)=1;
    all_patterns(:,2)=P2;
    subplot(2,5,2)
    imm=vecToIm(P2,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 2'), axis image
    somma_pattern=somma_pattern+imm;%检查每个物体不正交，即值为0或1
    %P3
    P3=P(:);
    pos3=[8:12 25:29 40:42 53:55 ];
    P3(pos3)=1;
    all_patterns(:,3)=P3;
    subplot(2,5,3)
    imm=vecToIm(P3,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 3'), axis image
    somma_pattern=somma_pattern+imm;
    %P4
    P4=P(:);
    pos4=[13:15 43:45 56:57 145:150 153:154 ];
    P4(pos4)=1;
    all_patterns(:,4)=P4;
    subplot(2,5,4)
    imm=vecToIm(P4,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 4'), axis image
    somma_pattern=somma_pattern+imm;
    %P5
    P5=P(:);
    pos5=[61:65 76:78 91:93 106:110 ];
    P5(pos5)=1;
    all_patterns(:,5)=P5;
    subplot(2,5,5)
    imm=vecToIm(P5,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 5'), axis image
    somma_pattern=somma_pattern+imm;
    %P6
    P6=P(:);
    pos6=[98:103 130:135 128:129 151:152 ];
    P6(pos6)=1;
    all_patterns(:,6)=P6;
    subplot(2,5,6)
    imm=vecToIm(P6,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 6'), axis image
    somma_pattern=somma_pattern+imm;
    %P7
    P7=P(:);
    pos7=[58:60 72:75 84:90 104:105 ];
    P7(pos7)=1;
    all_patterns(:,7)=P7;
    subplot(2,5,7)
    imm=vecToIm(P7,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 7'), axis image
    somma_pattern=somma_pattern+imm;
    %P8
    P8=P(:);
    pos8=[66:71 81:82 96:97 111:116 ];
    P8(pos8)=1;
    all_patterns(:,8)=P8;
    subplot(2,5,8)
    imm=vecToIm(P8,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 8'), axis image
    somma_pattern=somma_pattern+imm;
    %P9
    P9=P(:);
    pos9=[94:95 121:127 140:144 155:156 ];
    P9(pos9)=1;
    all_patterns(:,9)=P9;
    subplot(2,5,9)
    imm=vecToIm(P9,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 9'), axis image
    somma_pattern=somma_pattern+imm;
    % P10, 
    P10=P(:);
    pos10=[1:7 16:18 31:33 46:48];% 1:7 16:18 31:33 46:48
    P10(pos10)=1;
    all_patterns(:,10)=P10;
    subplot(2,5,10)
    imm=vecToIm(P10,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 10 (2*)'), axis image
    somma_pattern=somma_pattern+imm;
    
    % figure, imagesc(somma_pattern)
    clear P
elseif SET_PATT==4
    all_patterns=zeros(N*M,9);
    figure
    %P1
    P1=P(:);
    pos1=[1:15 21:35 41:50];
    P1(pos1)=1;
    all_patterns(:,1)=P1;
    subplot(331)
    imm=vecToIm(P1,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 1'), axis image
    somma_pattern=imm;
    %P2
    P2=P(:);
    pos2=[14:20 34:40 49:60 67:80 ];
    P2(pos2)=1;
    all_patterns(:,2)=P2;
    subplot(332)
    imm=vecToIm(P2,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 2'), axis image
    somma_pattern=somma_pattern+imm;
    %P3
    P3=P(:);
    pos3=[1:3 21:23 57:60 77:80 120:135 140:149];
    P3(pos3)=1;
    all_patterns(:,3)=P3;
    subplot(333)
    imm=vecToIm(P3,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 3'), axis image
    somma_pattern=somma_pattern+imm;
    %P4
    P4=P(:);
    pos4=[61:65 81:85 101:105 121:125 160:179 ];
    P4(pos4)=1;
    all_patterns(:,4)=P4;
    subplot(334)
    imm=vecToIm(P4,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 4'), axis image
    somma_pattern=somma_pattern+imm;
    %P5
    P5=P(:);
    pos5=[ 86:96 106:116 136:139 156:159 180:189 ];
    P5(pos5)=1;
    all_patterns(:,5)=P5;
    subplot(335)
    imm=vecToIm(P5,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 5'), axis image
    somma_pattern=somma_pattern+imm;
    %P6
    P6=P(:);
    pos6=[ 97:99 117:119 190:199 216:219 237:240 245:260 ];
    P6(pos6)=1;
    all_patterns(:,6)=P6;
    subplot(336)
    imm=vecToIm(P6,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 6'), axis image
    somma_pattern=somma_pattern+imm;
    %P7
    P7=P(:);
    pos7=[86:89 106:109 200:215 220:235 ];
    P7(pos7)=1;
    all_patterns(:,7)=P7;
    subplot(337)
    imm=vecToIm(P7,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 7'), axis image
    somma_pattern=somma_pattern+imm;
   
    clear P
elseif SET_PATT==5
    all_patterns=zeros(N*M,9);
    figure
    %P1
    P1=P(:);
    pos1=[1:14 21:34 41:54];
    P1(pos1)=1;
    all_patterns(:,1)=P1;
    subplot(331)
    imm=vecToIm(P1,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 1'), axis image
    somma_pattern=imm;
    %P2
    P2=P(:);
    pos2=[10:20 30:40 50:60 70:80 ];
    P2(pos2)=1;
    all_patterns(:,2)=P2;
    subplot(332)
    imm=vecToIm(P2,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 2'), axis image
    somma_pattern=somma_pattern+imm;
    %P3
    P3=P(:);
    pos3=[65:69 85:89 105:109 125:129 145:149 165:169 185:189 205:209];
    P3(pos3)=1;
    all_patterns(:,3)=P3;
    subplot(333)
    imm=vecToIm(P3,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 3'), axis image
    somma_pattern=somma_pattern+imm;
    %P4
    P4=P(:);
    pos4=[140:148 160:168 180:188 200:204 220:228 ];
    P4(pos4)=1;
    all_patterns(:,4)=P4;
    subplot(334)
    imm=vecToIm(P4,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 4'), axis image
    somma_pattern=somma_pattern+imm;
    %P5
    P5=P(:);
    pos5=[ 200:204 220:224 240:244 260:264 280:284 300:304 320:324 340:344];
    P5(pos5)=1;
    all_patterns(:,5)=P5;
    subplot(335)
    imm=vecToIm(P5,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 5'), axis image
    somma_pattern=somma_pattern+imm;
    %P6
    P6=P(:);
    pos6=[ 61:64 81:84 101:104 121:124 150:159 170:179 190:193 ];
    P6(pos6)=1;
    all_patterns(:,6)=P6;
    subplot(336)
    imm=vecToIm(P6,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 6'), axis image
    somma_pattern=somma_pattern+imm;
    %P7
    P7=P(:);
    pos7=[1:3 21:23 41:43 90:100 110:120 130:139 ];
    P7(pos7)=1;
    all_patterns(:,7)=P7;
    subplot(337)
    imm=vecToIm(P7,N,M);
    imagesc(~imm), hold on, colormap gray, grid on, title('object 7'), axis image
    somma_pattern=somma_pattern+imm;
   
    clear P
end