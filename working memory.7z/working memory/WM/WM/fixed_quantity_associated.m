%% 1. 读取Excel数据（请修改路径）
excel_path = 'C:/Users/86157/Desktop/定量.xlsx';  % 替换为你的文件路径
sheet_name = '联想';  % 工作表名

% 读取表格
data_table = readtable(excel_path, 'Sheet', sheet_name);

% 检查列名（按你的表格自动识别）
if ~all(ismember(data_table.Properties.VariableNames, {'Var1', 'Var2', 'Var3'}))
    error('表格列名不匹配，请确保是三列：实验条件、对象、发放率');
end

% 重命名列，方便后续调用
data_table.Properties.VariableNames = {'Condition', 'Object', 'Rate'};

%% 2. 按条件筛选数据
conditions = {'normal', 'remove'};
objects = {'pos1', 'pos4'};

% 初始化分组数据存储
grouped_data = struct();
for cond_idx = 1:length(conditions)
    cond = conditions{cond_idx};
    grouped_data.(cond) = struct();
    for obj_idx = 1:length(objects)
        obj = objects{obj_idx};
        % 筛选条件
        mask = strcmp(data_table.Condition, cond) & strcmp(data_table.Object, obj);
        rate_data = data_table.Rate(mask);
        rate_data = rate_data(~isnan(rate_data));  % 去除NaN
        grouped_data.(cond).(obj) = rate_data;
        
        if isempty(rate_data)
            warning('条件：%s，对象：%s 无有效数据！', cond, obj);
        end
    end
end

%% 3. 计算均值和方差
stats = struct();
disp('========== 均值和方差统计结果 ==========');
for cond_idx = 1:length(conditions)
    cond = conditions{cond_idx};
    stats.(cond) = struct();
    for obj_idx = 1:length(objects)
        obj = objects{obj_idx};
        rate_data = grouped_data.(cond).(obj);
        if ~isempty(rate_data)
            stats.(cond).(obj).mean = mean(rate_data);
            stats.(cond).(obj).var = var(rate_data);
            fprintf('%s条件 - %s：均值=%.6f，方差=%.6f\n', ...
                cond, obj, stats.(cond).(obj).mean, stats.(cond).(obj).var);
        else
            stats.(cond).(obj).mean = NaN;
            stats.(cond).(obj).var = NaN;
            fprintf('%s条件 - %s：无数据\n', cond, obj);
        end
    end
end

%% 4. 整理箱形图数据
box_data = [
    grouped_data.normal.pos1;
    grouped_data.remove.pos1;
    grouped_data.normal.pos4;
    grouped_data.remove.pos4
]';

labels = {'pos1-normal', 'pos1-remove', 'pos4-normal', 'pos4-remove'};

%% 5. 绘制箱形图（移除旧版本不支持的参数）
figure('Color','white','Position',[100,100,800,500]);
boxplot(box_data, labels, ...  % 旧版本Labels直接作为第二个参数
    'Colors', [0.2 0.6 0.8; 0.8 0.3 0.3; 0.2 0.6 0.8; 0.8 0.3 0.3]);  % 仅保留颜色参数

% 图表美化（适配所有MATLAB版本）
title('normal/remove条件下pos1、pos4的平均发放率箱形图','FontSize',14,'FontWeight','bold');
ylabel('平均发放率','FontSize',12);
xlabel('实验条件 & 对象','FontSize',12);
grid on;
set(gca,'FontSize',10);