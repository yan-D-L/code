% 定义10个对象的颜色
nature_colors = [
   0.878 0.78  0.941;  % 对象1颜色 #E0C5F2
   0.933 0.467  0.2;   % 对象2颜色 #EE7733
   0.2   0.667  0.933; % 对象3颜色 #33BBEE
   0.733 0.733  0.733; % 对象4颜色 #BBBBBB
   0.5  0.294  0.816;  % 对象5颜色 #7F4BB1
   0.8   0.2    0.067; % 对象6颜色 #CC3311
   0    0.467  0.741;  % 对象7颜色 #0077BB 
   0.984 0.835  0.667; % 对象8颜色 #FBD5B4
   0    0.6    0.533;  % 对象9颜色 #009988
   0.902 0.353  0.314; % 对象10颜色 #E78951
];

% 10个物体对应的神经元索引（Y轴值）
pos1 = [19:24 34:39 49:52];
pos2 = [66:71 81:82 96:97 111:116];
pos3 = [8:12 25:29 40:42 53:55];
pos4 = [13:15 43:45 56:57 145:150 153:154];
pos5 = [61:65 76:78 91:93 106:110];
pos6 = [98:103 130:135 128:129 151:152];
pos7 = [58:60 72:75 84:90 104:105];
pos8 = [79:80 117:120 137:138 158:165];
pos9 = [94:95 121:127 140:144 155:156];
pos10 = [1:7 16:18 31:33 46:48];

% 加载数据
zp3 = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\figure6.mat', 'zp3').zp3;

% 任务索引定义
idx_color = [19:24, 79:80, 117:120, 8:12, 25, 13:15, 43:45, ...
             61:65, 76, 98:103, 58:60, 72:74, 66:71, 94:95, 121:124, 1:6];
idx_location = [34:39, 137:138, 158:161, 26:29, 40:41, 56:57, 145:148, ...
                77:78, 91:93, 106, 130:135, 75, 84:88, 111:116, 125:127, ...
                140:142, 7, 16:18, 31:32];
idx_size = [49:52, 162:165, 42, 53:55, 149:150, 153:154, 107:110, ...
            128:129, 151:152, 89:90, 104:105, 81:82, 96:97, ...
            143:144, 155:156, 33, 46:48];

% 创建图形
figure; hold on;
title('Activation map by feature type', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
xlabel('Time (s)', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12); ylabel('Neuron Index', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
threshold = 4.2;

% 定义任务标记样式
task_markers = {'*', '^', 'o'};

% -------------------------- 图例调整核心代码 --------------------------
% 1. 预生成任务图例（黑色形状，放在前面）
h1 = plot(nan, nan, 'k*', 'MarkerSize', 5); % color任务：黑色加号
h2 = plot(nan, nan, 'k^', 'MarkerSize', 5); % location任务：黑色圆形
h3 = plot(nan, nan, 'ko', 'MarkerSize', 5); % size任务：黑色三角形


% 为每个神经元索引确定其所属对象
max_neuron = 165;
neuron_to_object = zeros(1, max_neuron);
for objIdx = 1:10
    neurons = eval(['pos', num2str(objIdx)]);
    neuron_to_object(neurons) = objIdx;
end

% 绘制color任务数据点
for i = 1:length(idx_color)
    neuron_idx = idx_color(i);
    objIdx = neuron_to_object(neuron_idx);
    if objIdx == 0, continue; end
    t = find(zp3(neuron_idx, :) > threshold);
    if ~isempty(t)
        plot(t*0.0001, neuron_idx * ones(size(t)), task_markers{1}, ...
             'Color', nature_colors(objIdx, :), 'MarkerSize', 15);
    end
end

% 绘制location任务数据点
for i = 1:length(idx_location)
    neuron_idx = idx_location(i);
    objIdx = neuron_to_object(neuron_idx);
    if objIdx == 0, continue; end
    t = find(zp3(neuron_idx, :) > threshold);
    if ~isempty(t)
        plot(t*0.0001, neuron_idx * ones(size(t)), task_markers{2}, ...
             'Color', nature_colors(objIdx, :), 'MarkerSize', 15, 'MarkerFaceColor', 'none');
    end
end

% 绘制size任务数据点
for i = 1:length(idx_size)
    neuron_idx = idx_size(i);
    objIdx = neuron_to_object(neuron_idx);
    if objIdx == 0, continue; end
    t = find(zp3(neuron_idx, :) > threshold);
    if ~isempty(t)
        plot(t*0.0001, neuron_idx * ones(size(t)), task_markers{3}, ...
             'Color', nature_colors(objIdx, :), 'MarkerSize', 15, 'MarkerFaceColor', 'none');
    end
end

% 设置坐标轴范围
ylim([1 165]);
xlim([1 size(zp3, 2)]*0.0001);
legend([h1 h2 h3], ...  % 图形句柄
       {'Task (color)', 'Task (location)', 'Task (size)'}, ...  % 图例文本（单独作为一个参数）
       'FontName', 'Arial', ...  % 图例字体：Arial
       'FontSize', 12);          % 图例字号：12
box on;
hold off;