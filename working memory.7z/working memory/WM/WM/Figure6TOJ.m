% Lo script richiede che siano gi� costruiti i pattern; si faccia uso della prima sezione
% di MAIN a tal scopo.
%% test rete intera (recall di sequenze) + Working Memory 
clc
MAIN


train_flag=0; 
load_sinapsi

 t_sim=0.8;%0.8
dt=0.0001;
t=0:dt:t_sim;
A_L2L2=A_L2L2*0.68;%2/3 0.68  0.48
 A_L3L3=A_L3L3*0.68;
  
  
 Wp_L1WM=1.1*Wp_L1WM;  %
 

  % Wp_L2L3 = 0*Wp_L2L3;%26:27  56:57  20:24
  % Wp_L2L1 = 0.9*Wp_L2L1;
  % Wp_L3L2 = 0.92*Wp_L3L2;

INPUT_WM=zeros(numero_colonne,length(t));

INPUT_WM([19:24,34:35],51:550)=1;
% buff=zeros(numero_colonne, round(0.05/dt));
% pos=find(corrupt_pattern(all_patterns(:,3))==1);
% buff(pos,:)=1;
% INPUT_WM(:,9751:10250)=buff;
% buff=zeros(numero_colonne, round(0.06/dt));
% pos=find(corrupt_pattern(all_patterns(:,2))==1);
% buff(pos,:)=1;
% INPUT_WM(:,15951:16550)=buff;
% buff=zeros(numero_colonne, round(0.05/dt));
% pos=find(corrupt_pattern(all_patterns(:,4))==1);
% buff(pos,:)=1;
% INPUT_WM(:,24051:24550)=buff;

reteWM_sim, IN0=INPUT_WM*230+np0;
% pjv6=sum(vp1(pos1,:))/size(pos1,2)+sum(vp1(pos2,:))/size(pos2,2)+sum(vp1(pos3,:))/size(pos3,2)+sum(vp1(pos4,:))/size(pos4,2)+sum(vp1(pos5,:))/size(pos5,2)+sum(vp1(pos6,:))/size(pos6,2)+sum(vp1(pos7,:))/size(pos7,2)+sum(vp1(pos8,:))/size(pos8,2)+sum(vp1(pos9,:))/size(pos9,2)+sum(vp1(pos10,:))/size(pos10,2);
% pjv6= vp3(:, 1050:8036);
% pjz6= zp3(:, 1050:8036);
% 初始化
% 初始化
threshold = 3.5; % 设定阈值
time_intervals = cell(10, 1); % 用于保存每个 posi 的时间段[开始,结束]
rise_times = cell(10, 1);     % 保存上升时间（从0.2到阈值的上升时间）
durations = cell(10, 1);      % 新增：保存每个区间的持续时间（结束-开始）

% 循环计算每个 posi 的时间段（如需计算1-10，将i=1:1改为i=1:10即可）
for i = 1:1
    % 动态获取 pos1 到 pos10，计算该posi下的平均值
    posi = eval(sprintf('pos%d', i)); 
    average_zp3_posi = sum(zp3(posi, :)) / size(posi, 2);

    % 找到超过阈值的时间点索引
    exceed_indices = find(average_zp3_posi > threshold);

    % 找出连续的时间段并计算相关参数
    if ~isempty(exceed_indices)
        exceed_diff = diff(exceed_indices);         % 计算索引差值，判断连续区间
        segment_ends = exceed_indices([find(exceed_diff > 1), end]);   % 各区间结束索引
        segment_starts = exceed_indices([1, find(exceed_diff > 1) + 1]); % 各区间起始索引

        % 保存当前i的时间段[开始时间, 结束时间]
        time_intervals{i} = [t(segment_starts)', t(segment_ends)'];
        % 初始化上升时间和持续时间数组
        rise_times{i} = zeros(size(segment_starts));
        durations{i} = zeros(size(segment_starts));
        
        for j = 1:length(segment_starts)
            % 计算当前区间持续时间：结束时间 - 开始时间（核心新增）
            durations{i}(j) = t(segment_ends(j)) - t(segment_starts(j));
            
            % 阈值交叉时刻：首次超过阈值的时刻（区间起始时刻）
            threshold_cross_time = t(segment_starts(j));

            % 查找阈值交叉前最后一次低于0.2的位置，用于计算上升时间
            below_idx = find(average_zp3_posi(1:segment_starts(j)) < 0.2, 1, 'last');
            if ~isempty(below_idx) && below_idx < segment_starts(j)
                % 线性插值求解刚好为0.2的时刻，提高精度
                v1 = average_zp3_posi(below_idx);
                v2 = average_zp3_posi(below_idx+1);
                t1 = t(below_idx);
                t2 = t(below_idx+1);
                t_at_0p2 = t1 + (0.2 - v1) * (t2 - t1) / (v2 - v1);
                % 上升时间：0.2时刻 到 首次超阈值时刻 的时间差
                rise_times{i}(j) = threshold_cross_time - t_at_0p2;
            else
                rise_times{i}(j) = NaN; % 未找到0.2起始点，标记为NaN
            end
        end
    else
        % 无超阈值区间时，相关变量置空
        time_intervals{i} = [];
        rise_times{i} = [];
        durations{i} = [];
    end
end

% 显示结果：时间段、持续时间、上升时间
disp('=============================================');
disp('结果：超阈值区间（持续时间+上升时间）');
disp('=============================================');
for i = 1:1
    fprintf('pos%d 结果：\n', i);
    if ~isempty(time_intervals{i})
        intervals = time_intervals{i};
        rise_time_vals = rise_times{i};
        duration_vals = durations{i};
        % 逐行输出：开始时间、结束时间、持续时间、上升时间
        for j = 1:size(intervals, 1)
            fprintf('  区间：%.4f s ~ %.4f s | 持续时间：%.4f s | 上升时间：%.4f s\n', ...
                intervals(j, 1), intervals(j, 2), duration_vals(j), rise_time_vals(j));
        end
    else
        fprintf('  无超过阈值的区间\n');
    end
end
%save('figure2.mat' )

line = 2.0;
font = 14;
% 定义 Nature 期刊风格的颜色方案
nature_colors = [
   0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB


    0.5  0.294  0.816;  % #7F4BB1
    0.8   0.2    0.067;  % #CC3311
    0    0.467  0.741;  % #0077BB 
    0.984 0.835  0.667;  % #FBD5B4
    0    0.6    0.533;  % #009988
    0.902 0.353  0.314;  % #E78951
];

figure;

% 第一个子图
subplot(511), hold on, ylabel('Input'), axis([0 t_sim -30 150])
plot(t, sum(IN0(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(IN0(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(IN0(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(IN0(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(IN0(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(IN0(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(IN0(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(IN0(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(IN0(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(IN0(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第二个子图
subplot(512), hold on, ylabel('z_p^{L_0} (Hz)', ...  % TeX语法：直接使用^和_，无需$包裹
       'Interpreter', 'tex', ...  % 启用TeX解释器（替代latex）
       'FontName', 'Arial', ...   % 保留Arial字体
       'FontSize', font), axis([0 t_sim 0 5])        % 字体大小 axis([0 t_sim 0 5])
plot(t, sum(zp0(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp0(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp0(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp0(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp0(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp0(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp0(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp0(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp0(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp0(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第三个子图
subplot(513), hold on, ylabel('z_p^{L_1} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), axis([0 t_sim 0 5])
plot(t, sum(zp1(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp1(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp1(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp1(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp1(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp1(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp1(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp1(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp1(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp1(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第四个子图
subplot(514), hold on, ylabel('z_p^{L_2} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), axis([0 t_sim 0 5])
plot(t, sum(zp2(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp2(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp2(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp2(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp2(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp2(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp2(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp2(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp2(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp2(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
set(gca, 'fontsize', font)

% 第五个子图
subplot(515), hold on, ylabel('z_p^{L_3} (Hz)', ...  % 第一个参数：文本内容
       'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
       'FontName','Arial', ...     % 第二个属性：字体为Arial
       'FontSize',font), xlabel('time (s)'), axis([0 t_sim 0 5])
plot(t, sum(zp3(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
plot(t, sum(zp3(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
plot(t, sum(zp3(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
plot(t, sum(zp3(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
plot(t, sum(zp3(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
plot(t, sum(zp3(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
plot(t, sum(zp3(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
plot(t, sum(zp3(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
plot(t, sum(zp3(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
plot(t, sum(zp3(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% 添加 y=3.5 的肉棕色虚线
 plot([0, t_sim], [3.5, 3.5], '--', 'Color', [0, 0, 0], 'lineWidth', 1)
 plot([0, t_sim], [0.2, 0.2], '--', 'Color', [0, 0, 0], 'lineWidth', 1)
set(gca, 'fontsize', font)
legend('Object 1','Object 2','Object 3','Object 4','Object 5','Object 6','Object 7', 'Object 8','Object 9', 'Object 10')%, 'obj8','obj9'