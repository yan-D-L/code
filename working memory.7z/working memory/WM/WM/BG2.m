% 参数初始化
dt = 0.01;        % 时间步长
T = 1000;         % 模拟时间
N = T/dt;         % 时间步数
e0 = 1;           % 激活函数参数
r = 5;            % 激活函数斜率
s0 = 0.5;         % 激活函数阈值

% 连接权重矩阵（不包含 C(1,9)）
C = zeros(1, 8);
C(1) = 0.5; % C_ep (兴奋性中间神经元到锥体神经元的连接)
C(2) = 1.0; % C_pe (锥体神经元到兴奋性中间神经元)
C(3) = 0.8; % C_sp (慢速抑制中间神经元到锥体神经元)
C(4) = 0.5; % C_ps (锥体神经元到慢速抑制中间神经元)
C(5) = 0.7; % C_fs (快速抑制中间神经元到慢速抑制中间神经元)
C(6) = 1.0; % C_fp (锥体神经元到快速抑制中间神经元)
C(7) = 0.6; % C_pf (快速抑制中间神经元到锥体神经元)
C(8) = 0.9; % C_ff (快速抑制中间神经元的自反馈)

% 基底神经节模型参数
K_fp = 0.8;      % 快速抑制中间神经元权重
K_sp = 0.7;      % 慢速抑制中间神经元权重
A_fp = 1.2;      % 快速抑制中间神经元调节
A_sp = 1.0;      % 慢速抑制中间神经元调节

% 状态变量初始化
vp0 = zeros(1, N); ve0 = zeros(1, N); vs0 = zeros(1, N); vf0 = zeros(1, N);
xp0 = zeros(1, N); yp0 = zeros(1, N);
xe0 = zeros(1, N); ye0 = zeros(1, N);
xs0 = zeros(1, N); ys0 = zeros(1, N);
xl0 = zeros(1, N); yl0 = zeros(1, N);
xf0 = zeros(1, N); yf0 = zeros(1, N);

% 模拟迭代
for k = 1:N-1
    % 计算锥体细胞的电位输入，结合兴奋性输入和基底神经节机制
    vp0(k) = C(2)*ye0(k) - C(4)*ys0(k) - C(7)*yf0(k) + C(1)*ze0(k); % 兴奋性+抑制性输入
    ve0(k) = C(1)*yp0(k);   % 兴奋性中间神经元的输入
    vs0(k) = C(3)*yp0(k);   % 慢速抑制中间神经元的输入
    vf0(k) = C(6)*yp0(k) - C(5)*ys0(k) - C(8)*yf0(k); % 快速抑制中间神经元的输入
    
    % 激活函数计算 (spikes)
    zp0(k) = 2*e0/(1 + exp(-r*(vp0(k) - s0)));
    ze0(k) = 2*e0/(1 + exp(-r*(ve0(k) - s0)));
    zs0(k) = 2*e0/(1 + exp(-r*(vs0(k) - s0)));
    zf0(k) = 2*e0/(1 + exp(-r*(vf0(k) - s0)));
    
    % 更新工作记忆层
    xp0(k+1) = xp0(k) + (K_fp*zp0(k) - 2*zp0(k) - A_fp*yp0(k))*dt;
    yp0(k+1) = yp0(k) + xp0(k)*dt;
    
    xe0(k+1) = xe0(k) + (K_sp*(ze0(k) + vp0(k)/C(2)) - 2*xe0(k) - A_sp*ye0(k))*dt;
    ye0(k+1) = ye0(k) + xe0(k)*dt;
    
    xs0(k+1) = xs0(k) + (K_sp*zs0(k) - 2*xs0(k) - A_sp*ys0(k))*dt;
    ys0(k+1) = ys0(k) + xs0(k)*dt;
    
    xl0(k+1) = xl0(k) + (K_fp*zp0(k) - 2*xl0(k) - A_fp*yl0(k))*dt;
    yl0(k+1) = yl0(k) + xl0(k)*dt;
    
    xf0(k+1) = xf0(k) + (K_fp*zf0(k) - 2*xf0(k) - A_fp*yf0(k))*dt;
    yf0(k+1) = yf0(k) + xf0(k)*dt;
end