% STDP参数
tau_pos = 20;    % 增强的时间常数 (ms)
tau_neg = 20;    % 抑制的时间常数 (ms)
A_pos = 0.005;   % 增强的幅度
A_neg = 0.005;   % 抑制的幅度

% 假设 ATT_PRE 和 ATT_POST 代表每个时间步的活动水平
ATT_PRE = (zp2(:, k) / (2 * e0) - thresh_low)'; % 1x400
ATT_PRE(ATT_PRE < 0) = 0; % 如果活动<0，列被关闭...

ATT_POST = (zf2(:, k) / (2 * e0) - thresh_low); % 400x1
ATT_POST(ATT_POST < 0) = 0;

% 基于时间差的STDP权重更新
delta_t = ATT_POST - ATT_PRE'; % 计算时间差矩阵 (400x400)
W_update = zeros(size(delta_t)); % 初始化权重更新

% 增强（前突触脉冲先于后突触脉冲）
W_update(delta_t > 0) = A_pos * exp(-delta_t(delta_t > 0) / tau_pos);

% 抑制（后突触脉冲先于前突触脉冲）
W_update(delta_t < 0) = -A_neg * exp(delta_t(delta_t < 0) / tau_neg);

% 应用STDP更新到权重，使用现有的 WEIGHT_k 作为乘子
K_L2L2 = K_L2L2 + gammaK .* W_update .* WEIGHT_k;                       8