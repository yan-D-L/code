clear
clc
close all

%% 1. 基础参数与4个图案定义（保留原始位置）
disp("choose the pattern with variable dimensions (number 2)")
N=11;  % Y轴像素数(1-11，共11个像素点)
M=15;  % X轴像素数(1-15，共15个像素点)
numero_colonne=N*M;

P=zeros(M*N,1);
all_patterns=zeros(N*M,4);

% 定义4个图案的位置（完全保留原始定义，像素点映射1-15/1-11）
P1=P(:); pos1=[19:24 34:39 49:52]; P1(pos1)=1; all_patterns(:,1)=P1;
P2=P(:); pos2=[66:71 41:42 54:55 111:116]; P2(pos2)=1; all_patterns(:,2)=P2;
P3=P(:); pos3=[8:12 25:29 40:42 53:55]; P3(pos3)=1; all_patterns(:,3)=P3;
P4=P(:); pos4=[13:15 43:45 49:52 145:150]; P4(pos4)=1; all_patterns(:,4)=P4;

%% 2. 颜色叠加（保留原始逻辑，像素点映射正确）
nature_colors = [
   0.878 0.78  0.941 ;  % #E0C5F2 (Object1)
   0.933 0.467  0.2   ;  % #EE7733 (Object2)
   0.2   0.667  0.933 ;  % #33BBEE (Object3)
   0.733 0.733  0.733 ;  % #BBBBBB (Object4)
];

RGB = ones(N, M, 3);  % 11行×15列，对应Y:1-11、X:1-15的像素点
alpha = 1;  % 透明度
for i = 1:4
    % 向量转矩阵：直接映射为11行（Y1-11）×15列（X1-15）的像素点
    pattern_img = reshape(all_patterns(:,i), M, N)';  
    mask = double(pattern_img > 0);
    for c = 1:3
        RGB(:,:,c) = RGB(:,:,c) - alpha * mask .* (1 - nature_colors(i, c));
    end
end
RGB = min(max(RGB, 0), 1);  % 确保颜色值在0-1范围内

%% 3. 绘图核心（像素点与1-15/1-11轴精准对应）
figure('Position', [100, 100, 800, 450]);  % 加宽画布，预留图例空间
ax = axes('Parent', gcf);
hold(ax, 'on');

% 显示图像：每个像素点精准对应X1-15、Y1-11刻度
image(ax, 1:M, 1:N, RGB);  % 核心：X轴1-15对应15个像素列，Y轴1-11对应11个像素行
axis(ax, 'image');         % 强制每个像素点为正方形
axis(ax, 'tight');         % 紧凑显示，无空白条
xlim(ax, [0.5, M+0.5]);   % 刻度线位于像素点边界，1-15精准框选每个像素
ylim(ax, [0.5, N+0.5]);

% 轴设置：仅左下轴，刻度对应像素点
ax.XAxisLocation = 'bottom';
ax.YAxisLocation = 'left';
ax.Box = 'off';
ax.XTick = 1:M;  % X轴刻度1-15，每个刻度对应1个像素列的中心
ax.YTick = 1:N;  % Y轴刻度1-11，每个刻度对应1个像素行的中心
ax.XTickLabel = ax.XTick;
ax.YTickLabel = ax.YTick;

% 轴标题与样式（明确像素点对应关系）
xlabel(ax, 'Cortical Column Index (Pixel Column)', 'FontSize', 12, 'FontName', 'Arial');
ylabel(ax, 'Cortical Column Index (Pixel Row)', 'FontSize', 12, 'FontName', 'Arial');
ax.FontName = 'Arial';
ax.FontSize = 9;  % 缩小刻度字体，避免拥挤
ax.LineWidth = 1;

% 标题（保留原始）
title(ax, 'All 4 objects with overlapping features', 'FontSize', 12);

%% 4. 稳定显示图例（4个原始+2个组合对象）
% 计算组合对象颜色（保留原始逻辑）
combined_color1 = [1, 1, 1];  % Object1+Object4
for i = [1, 4]
    for c = 1:3
        combined_color1(c) = combined_color1(c) - (1 - nature_colors(i, c));
    end
end
combined_color1 = max(min(combined_color1, 1), 0);

combined_color2 = [1, 1, 1];  % Object2+Object3
for i = [2, 3]
    for c = 1:3
        combined_color2(c) = combined_color2(c) - (1 - nature_colors(i, c));
    end
end
combined_color2 = max(min(combined_color2, 1), 0);

% 生成有效图例句柄（确保图例显示）
legend_handles = [];
legend_labels = {};

% 原始对象1-4
for i = 1:4
    h = plot(ax, -10, -10, 's', ...
        'MarkerFaceColor', nature_colors(i,:), ...
        'MarkerEdgeColor', nature_colors(i,:), ...
        'MarkerSize', 10);
    legend_handles = [legend_handles, h];
    legend_labels = [legend_labels, sprintf('Object %d', i)];
end

% 组合对象1+4
h1 = plot(ax, -10, -10, 's', ...
    'MarkerFaceColor', combined_color1, ...
    'MarkerEdgeColor', combined_color1, ...
    'MarkerSize', 10);
legend_handles = [legend_handles, h1];
legend_labels = [legend_labels, 'Object 1+Object 4'];

% 组合对象2+3
h2 = plot(ax, -10, -10, 's', ...
    'MarkerFaceColor', combined_color2, ...
    'MarkerEdgeColor', combined_color2, ...
    'MarkerSize', 10);
legend_handles = [legend_handles, h2];
legend_labels = [legend_labels, 'Object 2+Object 3'];

% 创建图例（右侧外部+细边框）
lgd = legend(ax, legend_handles, legend_labels);
lgd.Location = 'eastoutside';
lgd.Position = [0.82, 0.1, 0.08, 0.3];  % 适配像素点显示的图例位置
lgd.LineWidth = 0.5;
lgd.FontName = 'Arial';
lgd.FontSize = 9;
lgd.Visible = 'on';

hold(ax, 'off');