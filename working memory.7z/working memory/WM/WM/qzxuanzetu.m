load('sinapsi_SET12.mat');

obj1_groups = {[19:24], [34:39], [49:52]};                                
obj4_groups = {[13:15], [43:45], [49:52], [145:150]};

% 提取所有 obj1 和 obj4 的神经元索引
idx_obj1 = unique([obj1_groups{:}]);
idx_obj4 = unique([obj4_groups{:}]);

% 创建空矩阵
Wp_selected = zeros(size(Wp_L1L1));

% 只保留 obj1 内部连接
Wp_selected(idx_obj1, idx_obj1) = Wp_L1L1(idx_obj1, idx_obj1);

% 只保留 obj4 内部连接
Wp_selected(idx_obj4, idx_obj4) = Wp_L1L1(idx_obj4, idx_obj4);

% 后面的绘图代码不变
color_obj1 = [0.878, 0.78, 0.941];   % #E0C5F2
color_obj4 = [0.733, 0.733, 0.733];  % #BBBBBB
color_both = [0.588, 0.494, 0.651];  % #967EA6

figure('Position', [100, 100, 900, 900]);

main_ax = axes('Position', [0.12, 0.12, 0.75, 0.75]);
imagesc(Wp_selected);
colorbar;
xlabel('L_1 (Output layer)', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
ylabel('L_1 (Input layer)', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
title('Weight connections of Object 1 and Object 4 in the layer L_1 ', ...
       'FontName', 'Arial', ...  % 指定Arial字体
       'FontSize', 12);
set(main_ax, 'YDir', 'normal');
hold on;

% 获取轴范围
x_max = size(Wp_selected, 2);
y_max = size(Wp_selected, 1);

% 创建X轴颜色条 (更小的尺寸，在主图下方)
% x_color_ax = axes('Position', [0.12, 0.08, 0.75, 0.03]);  % 高度减小为0.03
% axis(x_color_ax, 'off');
% hold(x_color_ax, 'on');
% xlim(x_color_ax, [1, x_max]);
% ylim(x_color_ax, [0, 1]);
% 
% % 创建Y轴颜色条 (更小的尺寸，在主图左侧)
% y_color_ax = axes('Position', [0.08, 0.12, 0.03, 0.75]);  % 宽度减小为0.03
% axis(y_color_ax, 'off');
% hold(y_color_ax, 'on');
% xlim(y_color_ax, [0, 1]);
% ylim(y_color_ax, [1, y_max]);
% set(y_color_ax, 'YDir', 'normal');
% 
% % 绘制X轴颜色条
% for i = 1:x_max
%     in_obj1 = any(cellfun(@(x)ismember(i, x), obj1_groups));
%     in_obj4 = any(cellfun(@(x)ismember(i, x), obj4_groups));
% 
%     if in_obj1 && in_obj4
%         fill(x_color_ax, [i-0.5, i+0.5, i+0.5, i-0.5], [0, 0, 1, 1], color_both, 'EdgeColor', 'none');
%     elseif in_obj1
%         fill(x_color_ax, [i-0.5, i+0.5, i+0.5, i-0.5], [0, 0, 1, 1], color_obj1, 'EdgeColor', 'none');
%     elseif in_obj4
%         fill(x_color_ax, [i-0.5, i+0.5, i+0.5, i-0.5], [0, 0, 1, 1], color_obj4, 'EdgeColor', 'none');
%     end
% end
% 
% % 绘制Y轴颜色条
% for i = 1:y_max
%     in_obj1 = any(cellfun(@(x)ismember(i, x), obj1_groups));
%     in_obj4 = any(cellfun(@(x)ismember(i, x), obj4_groups));
% 
%     if in_obj1 && in_obj4
%         fill(y_color_ax, [0, 1, 1, 0], [i-0.5, i-0.5, i+0.5, i+0.5], color_both, 'EdgeColor', 'none');
%     elseif in_obj1
%         fill(y_color_ax, [0, 1, 1, 0], [i-0.5, i-0.5, i+0.5, i+0.5], color_obj1, 'EdgeColor', 'none');
%     elseif in_obj4
%         fill(y_color_ax, [0, 1, 1, 0], [i-0.5, i-0.5, i+0.5, i+0.5], color_obj4, 'EdgeColor', 'none');
%     end
% end

% 添加图例
hold(main_ax, 'on');
h1 = plot(NaN, NaN, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color_obj1, 'MarkerEdgeColor', 'none');
h2 = plot(NaN, NaN, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color_obj4, 'MarkerEdgeColor', 'none');
h3 = plot(NaN, NaN, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color_both, 'MarkerEdgeColor', 'none');
legend([h1, h2, h3], 'Object 1', 'Object 4', 'Object 1+Object 4', ...
       'Location', 'best', 'Color', 'white', 'EdgeColor', 'none', ...
       'FontName', 'Arial', ...  % 图例字体也设为Arial
       'FontSize', 12);

% 确保所有轴同步
linkaxes([main_ax, x_color_ax], 'x');
linkaxes([main_ax, y_color_ax], 'y');
%obj1:19:24,34:39,49:52
%obj2:79:80,117:120,137:138,158:165
%obj4:13:15,43:45,56:57,145:150,153:154