K_L2L21=load('sinapsi_SET1.mat').K_L2L2;
K_L2L23=load('sinapsi_SET3.mat').K_L2L2;
difference=K_L2L23-K_L2L21;
% 绘制差值矩阵的色图
figure;
imagesc(difference); % 绘制色图
colormap('jet'); % 使用 'viridis' 色图 (需要 MATLAB 2017b 或更高版本)
colorbar;            % 添加颜色条
title('K_L2L2');    % 设置标题
xlabel('Columns');   % 设置横轴标签
ylabel('Rows');      % 设置纵轴标签
axis equal;          % 保持矩阵比例