 % Lo script richiede che siano gi� costruiti i pattern si faccia uso della prima sezione
% di MAIN a tal scopo.

%% test rete intera (DESYNC) - WM + L1,L2,L3
%no feedback L3->L2, connessioni tra L1 e WM (sia in avanti sia in feedback)
%triplicate.
%语义网络下   没有L3到L2的反馈，WM-L1的突触强度变大
clc
close all
clear
MAIN


train_flag=0 ;
M_fac = 1.5*0.68 ; % multiplicative factor, representing attention
load_sinapsi
t_sim=1.0;
dt=0.0001;
t=0:dt:t_sim;

% rows = [13:15, 43:45, 145:150];  
% cols = [49:52,19:24,34:39]; 


% Wp_L1L1(rows, cols) = 0;

nP=4;
INPUT_WM=zeros(numero_colonne,length(t)); 
% buff=zeros(numero_colonne, round(0.05/dt));%输入500时间步
% pos=find(corrupt_pattern(sum(all_patterns(:, 1),2))==1);%    2 3 5 9  2 3 4  7   1 2 3 4
% buff(pos,:)=1;
% INPUT_WM(:,1:500)=buff;
INPUT_WM([19:24,34:35],51:550)=1;
% buff=zeros(numero_colonne, round(0.05/dt));%输入500时间步
% pos=find(corrupt_pattern(sum(all_patterns(:, 2),2))==1);%    2 3 5 9  2 3 4  7   1 2 3 4
% buff(pos,:)=1;
% INPUT_WM(:,9551:10050)=buff;
% buff=zeros(numero_colonne, round(0.05/dt));%输入500时间步
% pos=find(corrupt_pattern(sum(all_patterns(:, 3),2))==1);%    2 3 5 9  2 3 4  7   1 2 3 4
% buff(pos,:)=1;
% INPUT_WM(:,15951:16450)=buff;

% position0=P1+P2+P3+P5;
% 
% diff=position0-position;

  if nP > 4
    A_L2L2=A_L2L2*M_fac;%多于4个对象时，1.7倍，增强A型突触会增加去同化能力
    A_L3L3=A_L3L3*M_fac;%多于4个对象时，1.7倍
  else
    A_L2L2=A_L2L2*0.58;%模式一：0.55  0.52 2/3
    A_L3L3=A_L3L3*0.58;
  end

% if nP>5
%     A_L2L2=A_L2L2*(1.025+0.025*(nP-3)) Ú +2.5% a +15%
%     A_L3L3=A_L3L3*(1.025+0.025*(nP-3))
% else
%     if nP == 5
 %   A_L2L2=A_L2L2*1.15
 %   A_L3L3=A_L3L3*1.15
%     else
%     A_L2L2=A_L2L2*2/3
%     A_L3L3=A_L3L3*2/3
%     end
% end

reteWM_desync1
IN0=INPUT_WM*230+np0;
% pjv7=sum(vp3(pos1,:))/size(pos1,2)+sum(vp3(pos2,:))/size(pos2,2)+sum(vp3(pos3,:))/size(pos3,2)+sum(vp3(pos4,:))/size(pos4,2)+sum(vp3(pos5,:))/size(pos5,2)+sum(vp3(pos6,:))/size(pos6,2)+sum(vp3(pos7,:))/size(pos7,2)+sum(vp3(pos8,:))/size(pos8,2)+sum(vp3(pos9,:))/size(pos9,2)+sum(vp3(pos10,:))/size(pos10,2);
%save('figure7.mat' )
% 初始化存储：最终单值平均（核心）+ 逐时间点发放率（可选验证）
final_avg_firing = zeros(1,4);  % 索引1/4：pos1/pos4全时间窗单一平均发放率（最终标量）
per_timestep_firing = cell(1,4);% 索引1/4：pos1/pos4每个时间点发放率（行向量，可选保留）
total_timesteps = size(zp3,2); % 获取总时间点数（zp3列数）

% 仅计算pos1、pos4，循环内完成「逐点平均→单值平均」两步计算
for i = [1,4]
    % 1. 动态获取pos1/pos4的神经元行索引
    posi = eval(sprintf('pos%d', i));
    % 2. 计算该pos【每个时间点】的平均发放率（适配zp3列=时间点，通用写法无维度错误）
    per_timestep_firing{i} = sum(zp3(posi, :)) / length(posi);
    % 3. 对逐时间点发放率求平均 → 得到全时间窗「单一标量值」（核心需求）
    final_avg_firing(i) = mean(per_timestep_firing{i});
end

% 结果输出：聚焦最终单一平均标量（直接用于对比分析）
disp('=== pos1/pos4 全时间窗单一平均发放率（所有时间点求和平均） ===');
fprintf('pos1 全时间窗平均发放率（%d个时间点）：%.6f\n', total_timesteps, final_avg_firing(1));
fprintf('pos4 全时间窗平均发放率（%d个时间点）：%.6f\n', total_timesteps, final_avg_firing(4));

% 快捷提取最终单值（直接复制到工作区，用于灰色/紫色物体对比、绘图、统计检验）
pos1_final_avg = final_avg_firing(1);
pos4_final_avg = final_avg_firing(4);
fprintf('\n【快捷提取最终值】\npos1_final_avg = %.6f;\npos4_final_avg = %.6f;\n', pos1_final_avg, pos4_final_avg);
font = 14;
line = 2.2;
%0.95, 0.75, 0.75;  % 亮粉
    % 0.75, 0.90, 0.95;  % 亮绿
    %  0.85, 0.75, 0.90;  % 亮青
    % 0.7, 0.90, 0.75;  % 亮青绿
nature_colors = [
    0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB


    0.5  0.294  0.816;  % #7F4BB1
    0.8   0.2    0.067;  % #CC3311
    0    0.467  0.741;  % #0077BB 
    0.984 0.835  0.667;  % #FBD5B4
    0    0.6    0.533;  % #009988
    0.902 0.353  0.314;  % #E78951



];

% figure
% y=1:400;
% %plot(y,position0,'r',y,position,'b','linewidth',1)
% % plot(y,diff,'b','linewidth',1)
% 
% 
% 
% subplot(511), hold on, ylabel('Input'), axis([0 t_sim -20 150])
% plot(t, sum(IN0(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
% plot(t, sum(IN0(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
% plot(t, sum(IN0(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
% plot(t, sum(IN0(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
% % plot(t, sum(IN0(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
% % plot(t, sum(IN0(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
% % plot(t, sum(IN0(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
% % plot(t, sum(IN0(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
% % plot(t, sum(IN0(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
% % plot(t, sum(IN0(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% set(gca, 'fontsize', font)
% 
% % 第二个子图
% subplot(512), hold on, ylabel('z_p^{L_0} (Hz)', ...  % 第一个参数：文本内容
%        'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
%        'FontName','Arial', ...     % 第二个属性：字体为Arial
%        'FontSize',font), axis([0 t_sim 0 5])
% plot(t, sum(zp0(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
% plot(t, sum(zp0(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
% plot(t, sum(zp0(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
% plot(t, sum(zp0(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
% plot(t, sum(zp0(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
% plot(t, sum(zp0(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
% plot(t, sum(zp0(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
% plot(t, sum(zp0(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
% plot(t, sum(zp0(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
% plot(t, sum(zp0(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% set(gca, 'fontsize', font)
% 
% % 第三个子图
% subplot(513), hold on, ylabel('z_p^{L_1} (Hz)', ...  % 第一个参数：文本内容
%        'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
%        'FontName','Arial', ...     % 第二个属性：字体为Arial
%        'FontSize',font), axis([0 t_sim 0 5])
% plot(t, sum(zp1(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
% plot(t, sum(zp1(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
% plot(t, sum(zp1(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
% plot(t, sum(zp1(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
% % plot(t, sum(zp1(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
% % plot(t, sum(zp1(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
% % plot(t, sum(zp1(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
% % plot(t, sum(zp1(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
% % plot(t, sum(zp1(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
% % plot(t, sum(zp1(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% set(gca, 'fontsize', font)
% 
% % 第四个子图
% subplot(514), hold on, ylabel('z_p^{L_2} (Hz)', ...  % 第一个参数：文本内容
%        'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
%        'FontName','Arial', ...     % 第二个属性：字体为Arial
%        'FontSize',font), axis([0 t_sim 0 5])
% plot(t, sum(zp2(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
% plot(t, sum(zp2(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
% plot(t, sum(zp2(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
% plot(t, sum(zp2(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
% % plot(t, sum(zp2(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
% % plot(t, sum(zp2(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
% % plot(t, sum(zp2(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
% % plot(t, sum(zp2(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
% % plot(t, sum(zp2(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
% % plot(t, sum(zp2(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% set(gca, 'fontsize', font)
% 
% % 第五个子图
% subplot(515), hold on, ylabel('z_p^{L_3} (Hz)', ...  % 第一个参数：文本内容
%        'Interpreter','tex', ...  % 仅保留1次：启用LaTeX解析公式
%        'FontName','Arial', ...     % 第二个属性：字体为Arial
%        'FontSize',font), xlabel('time (s)'), axis([0 t_sim 0 5])
% plot(t, sum(zp3(pos1,:))/size(pos1,2), 'Color', nature_colors(1,:), 'linewidth', line)
% plot(t, sum(zp3(pos2,:))/size(pos2,2), 'Color', nature_colors(2,:), 'linewidth', line)
% plot(t, sum(zp3(pos3,:))/size(pos3,2), 'Color', nature_colors(3,:), 'linewidth', line)
% plot(t, sum(zp3(pos4,:))/size(pos4,2), 'Color', nature_colors(4,:), 'linewidth', line)
% plot ([0 t_sim], [3.2 3.2], 'k--', 'linewidth', line)
% % plot(t, sum(zp3(pos5,:))/size(pos5,2), 'Color', nature_colors(5,:), 'linewidth', line)
% % plot(t, sum(zp3(pos6,:))/size(pos6,2),  'Color', nature_colors(6,:), 'linewidth', line)
% % plot(t, sum(zp3(pos7,:))/size(pos7,2),  'Color', nature_colors(7,:), 'linewidth', line)
% % plot(t, sum(zp3(pos8,:))/size(pos8,2),  'Color', nature_colors(8,:), 'linewidth', line)
% % plot(t, sum(zp3(pos9,:))/size(pos9,2),  'Color', nature_colors(9,:), 'linewidth', line)
% % plot(t, sum(zp3(pos10,:))/size(pos10,2),  'Color', nature_colors(10,:), 'linewidth', line)
% set(gca, 'fontsize', font)
% 
% 
% legend('Object 1','Object 2','Object 3','Object 4','Threshold','obj6','obj7', 'obj8','obj9','obj10')%