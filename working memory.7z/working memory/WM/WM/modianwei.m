load 'figure7.mat'
line = 1.0;
% plot(t, vp3(1,:), 'b', 'linewidth', line)
hold on
% plot(t, vf3(1,:), 'r', 'linewidth', line)
% plot(t, vs3(1,:), 'g', 'linewidth', line)
plot(t, vp3(8,:), 'k', 'linewidth', line)
hold off
legend('vp3')
xlabel('时间 t')
ylabel('膜电位')
title('不同神经元类型的膜电位变化')
grid on