% Lo script richiede che siano gi� costruiti i pattern si faccia uso della prima sezione
% di MAIN a tal scopo.
%% test su L1 & Working Memory
clc

MAIN
t_sim=.8;
dt=0.0001;
t=0:dt:t_sim;

train_flag=0 ;
load_sinapsi%选择三种不同模式

INPUT_WM=zeros(numero_colonne,8001);
buff=zeros(numero_colonne, round(0.05/dt));%对应不同时间内的输入
pos=find(corrupt_pattern(all_patterns(:,1))==1);%找到破损的模式1中对应位置为1的
buff(pos,:)=1;%令buff中（破损的模式1中对应位置为1）的行值为1
INPUT_WM(:,51:550)=buff;%对WM5.1ms-55ms输入buff，即对破损模式输入值为1
buff=zeros(numero_colonne, round(0.05/dt));
pos=find(corrupt_pattern(all_patterns(:,2))==1);
buff(pos,:)=1;
INPUT_WM(:,4051:4550)=buff;


WML1_sim, IN0=INPUT_WM*600+np0;%对WM输入破损的模式1，2以及一直的噪声

line = 1.5;
font = 14;
figure
subplot(311), title('Input to WM'), hold on, ylabel('Hz'),xlabel('time (s)')
plot(t,sum(IN0(pos1,:))/size(pos1,2),'linewidth',line), plot(t,sum(IN0(pos2,:))/size(pos2,2),'r','linewidth',line)%pos1 是模式中的第一种
set(gca,'fontsize',font)
subplot(312), title('z_p_,_W_M'), hold on, ylabel('Hz'), xlabel('time (s)')
plot(t,sum(zp0(pos1,:))/size(pos1,2),'linewidth',line), plot(t,sum(zp0(pos2,:))/size(pos2,2),'r','linewidth',line)%皮质柱的平均发放率
set(gca,'fontsize',font)
subplot(313), title('z_p_,_L_1'), hold on, ylabel('Hz'), xlabel('time (s)')
plot(t,sum(zp1(pos1,:))/size(pos1,2),'linewidth',line), plot(t,sum(zp1(pos2,:))/size(pos2,2),'r','linewidth',line)
set(gca,'fontsize',font)