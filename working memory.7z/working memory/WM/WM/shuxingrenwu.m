zp3 = load('C:\Users\86157\Desktop\WM\时间序列\AAPrograms_repository\figure6.mat', 'zp3').zp3;

% 任务索引定义
idx_color = [19:24, 79:80, 117:120, 8:12, 25, 13:15, 43:45, ...
             61:65, 76, 98:103, 58:60, 72:74, 66:71, 94:95, 121:124, 1:6];
idx_location = [34:39, 137:138, 158:161, 26:29, 40:41, 56:57, 145:148, ...
                77:78, 91:93, 106, 130:135, 75, 84:88, 111:116, 125:127, ...
                140:142, 7, 16:18, 31:32];
idx_size = [49:52, 162:165, 42, 53:55, 149:150, 153:154, 107:110, ...
            128:129, 151:152, 89:90, 104:105, 81:82, 96:97, ...
            143:144, 155:156, 33, 46:48];

% 创建 figure
figure; hold on;
title('Activation map by feature type');
xlabel('Time (s)'); ylabel('Neuron Index'); % 修改X轴标签为秒
threshold = 4.5;

% 预生成图例对象，使用不同形状和黑色
h1 = plot(nan, nan, 'ks', 'MarkerSize', 5); % color任务：黑色加号
h2 = plot(nan, nan, 'ko', 'MarkerSize', 5); % location任务：黑色圆形
h3 = plot(nan, nan, 'k^', 'MarkerSize', 5); % size任务：黑色三角形

% 绘制color任务（黑色加号）
for i = 1:length(idx_color)
    idx = idx_color(i);
    t = find(zp3(idx, :) > threshold);
    plot(t*0.0001, idx * ones(size(t)), 'ks', 'MarkerSize', 5); % X值乘以0.0001转换为秒
end

% 绘制location任务（黑色圆形）
for i = 1:length(idx_location)
    idx = idx_location(i);
    t = find(zp3(idx, :) > threshold);
    plot(t*0.0001, idx * ones(size(t)), 'ko', 'MarkerSize', 5); % X值乘以0.0001转换为秒
end

% 绘制size任务（黑色三角形）
for i = 1:length(idx_size)
    idx = idx_size(i);
    t = find(zp3(idx, :) > threshold);
    plot(t*0.0001, idx * ones(size(t)), 'k^', 'MarkerSize', 5); % X值乘以0.0001转换为秒
end

% 设置图示范围和图例
ylim([1 165]);
xlim([1 size(zp3, 2)]*0.0001); % X轴范围也乘以0.0001
legend([h1 h2 h3], {'a Task (color)', 'b Task (location)', 'c Task (size)'});
