clear
clc
close all

%%
disp("choose the pattern with variable dimensions (number 2)")
N=11;  % 行数
M=15;  % 列数
numero_colonne=N*M;

P=zeros(M*N,1);
all_patterns=zeros(N*M,4);

%P1
P1=P(:);
pos1=[19:24 34:39 49:52];
P1(pos1)=1;
all_patterns(:,1)=P1;

P2=P(:);
pos2=[66:71 41:42 54:55 111:116];
P2(pos2)=1;
all_patterns(:,2)=P2;

P3=P(:);
pos3=[8:12 25:29 40:42 53:55];
P3(pos3)=1;
all_patterns(:,3)=P3;

P4=P(:);
pos4=[13:15 43:45 49:52 145:150];
P4(pos4)=1;
all_patterns(:,4)=P4;

% ----------------------颜色合并图像显示-------------------------
% 定义颜色表
nature_colors = [
   0.878 0.78  0.941 ;  % #E0C5F2
     0.933 0.467  0.2   ;  % #EE7733
    0.2   0.667  0.933;  % #33BBEE
     0.733 0.733  0.733;  % #BBBBBB

];

% 初始化 RGB 图像为白色背景
RGB = ones(N, M, 3);  % 每个像素初始为 [1, 1, 1]（白色）
alpha = 1;  % 透明度

% 绘制所有图案
for i = 1:4
    pattern_img = vecToIm(all_patterns(:, i), N, M);
    mask = double(pattern_img > 0);
    
    for c = 1:3
        RGB(:,:,c) = RGB(:,:,c) - alpha * mask .* (1 - nature_colors(i, c));
    end
end

RGB = min(max(RGB, 0), 1);

% 计算重叠区域
overlap_mask = zeros(N, M);
for i = 1:4
    pattern_img = vecToIm(all_patterns(:, i), N, M);
    overlap_mask = overlap_mask + double(pattern_img > 0);
end
overlap_mask = overlap_mask > 1;  % 重叠区域

% 显示 RGB 图像
figure;
image(RGB);
axis image off;
title('All 4 objects with overlapping features');
hold on;

% 绘制外部15*11的边界
x = [0.5, M+0.5, M+0.5, 0.5, 0.5];
y = [0.5, 0.5, N+0.5, N+0.5, 0.5];
plot(x, y, 'k', 'LineWidth', 1);

% ---------------- 添加图例 ----------------
% 计算组合对象的颜色（使用与图中相同的减法叠加逻辑）
% 从白色开始，依次减去每个对象颜色的补色
combined_color1 = [1, 1, 1];  % 初始为白色
for i = [1, 4]  % 对象1和对象4的组合
    for c = 1:3
        combined_color1(c) = combined_color1(c) - (1 - nature_colors(i, c));
    end
end
combined_color1 = max(min(combined_color1, 1), 0);  % 确保在0-1范围内

combined_color2 = [1, 1, 1];  % 初始为白色
for i = [2, 3]  % 对象2和对象3的组合
    for c = 1:3
        combined_color2(c) = combined_color2(c) - (1 - nature_colors(i, c));
    end
end
combined_color2 = max(min(combined_color2, 1), 0);  % 确保在0-1范围内

% 创建图例句柄
legend_handles = cell(6, 1);
legend_labels = cell(6, 1);

% 原始对象1-4
for i = 1:4
    legend_handles{i} = plot(nan, nan, 's', ...
        'MarkerFaceColor', nature_colors(i,:), ...
        'MarkerEdgeColor', nature_colors(i,:), ...
        'MarkerSize', 10);
    
    legend_labels{i} = sprintf('Object %d', i);
end

% 组合对象1+4
legend_handles{5} = plot(nan, nan, 's', ...
    'MarkerFaceColor', combined_color1, ...
    'MarkerEdgeColor', combined_color1, ...
    'MarkerSize', 10);
legend_labels{5} = 'Object 1+Object 4';

% 组合对象2+3
legend_handles{6} = plot(nan, nan, 's', ...
    'MarkerFaceColor', combined_color2, ...
    'MarkerEdgeColor', combined_color2, ...
    'MarkerSize', 10);
legend_labels{6} = 'Object 2+Object 3';

% 创建图例
legend([legend_handles{:}], legend_labels, 'Location', 'eastoutside');
