if ~train_flag
    if SET_PATT==1
            load('sinapsi_SET11.mat')
    elseif SET_PATT==2
            load('sinapsi_SET12.mat')
    elseif SET_PATT==3
            load('sinapsi_SET13.mat')
    elseif SET_PATT==4
            load('sinapsi_SET4.mat')
    elseif SET_PATT==5
            load('sinapsi_SET5.mat')
    end
end
%选择模式