
%% parametri
dt=0.0001; %0.1 millisecondi
t_end1=2.5;
t=0:dt:t_end1;
T=length(t);

% Parametri sigmoide
e0=2.5; %Hz
r=0.7; %1/mV
s0=10; %centro della sigmoide

% ritardi nella comunicazione tra colonne diverse
D_intraLayer=1*round(dt/dt); 
D_extraLayer=3*round(dt/dt); %delay di 0.0166 secondi ?
                
% costanti di tempo sinapsi intra-colonna
a=[1/7.7 1/34 1/6.8]*1000; %nell'ordine: ae, as, af; a=1/tau (1/secondi)

% Guadagni (mV) delle sinapsi (G)
G=[5.17 4.45 57.1]; %Ge = 5.17; (per h_e)
                    %Gs = 4.45; (per h_s)
                    %Gf = 57.1; (per h_f)

%pesi sinaptici:
C(:,1) = 31.7*ones(1,numero_colonne); %Cep
C(:,2) = 17.3*ones(1,numero_colonne); %Cpe  
C(:,3) = 51.9*ones(1,numero_colonne); %Csp  51.9
C(:,4) = 100*ones(1,numero_colonne); %Cps 
C(:,5) = 100*ones(1,numero_colonne); %Cfs  100
C(:,6) = 66.9*ones(1,numero_colonne); %Cfp  66.9
C(:,7) = 12.3*ones(1,numero_colonne); %Cpf
C(:,8) = 18*ones(1,numero_colonne); %Cff
C(:,9) = 200*ones(1,numero_colonne); %Cpp

%% addestramento
% Wp_L2L1=zeros(numero_colonne,numero_colonne);
Wp_L2L1=0*ones(numero_colonne,numero_colonne);

thresh_low1=0.8;% 模式一0.99999     变成0.97之后9就会变小  0.6可以
thresh_low2=0.8;%0.99999
Wp_L2L1_max=9.7;%9.7
tau2=3020.4;%   3020
TOTSINW2=150;%150  210  高了图8最后一个记不起来
  



%var stato L2
yp2=zeros(numero_colonne,T);
xp2=zeros(numero_colonne,T);
vp2=zeros(numero_colonne,1); 
zp2=zeros(numero_colonne,T);

ye2=zeros(numero_colonne,T);
xe2=zeros(numero_colonne,T);
ve2=zeros(numero_colonne,1);
ze2=zeros(numero_colonne,T);

ys2=zeros(numero_colonne,T);
xs2=zeros(numero_colonne,T);
vs2=zeros(numero_colonne,1);
zs2=zeros(numero_colonne,T);

yf2=zeros(numero_colonne,T);
xf2=zeros(numero_colonne,T);
zf2=zeros(numero_colonne,T);
vf2=zeros(numero_colonne,1);

xl2=zeros(numero_colonne,T);
yl2=zeros(numero_colonne,T);

mf2=zeros(numero_colonne,1);

%var stato L3
yp1=zeros(numero_colonne,T);
xp1=zeros(numero_colonne,T);
vp1=zeros(numero_colonne,1); 
zp1=zeros(numero_colonne,T);

ye1=zeros(numero_colonne,T);
xe1=zeros(numero_colonne,T);
ve1=zeros(numero_colonne,1);
ze1=zeros(numero_colonne,T);

ys1=zeros(numero_colonne,T);
xs1=zeros(numero_colonne,T);
vs1=zeros(numero_colonne,1);
zs1=zeros(numero_colonne,T);

yf1=zeros(numero_colonne,T);
xf1=zeros(numero_colonne,T);
zf1=zeros(numero_colonne,T);
vf1=zeros(numero_colonne,1);

xl1=zeros(numero_colonne,T);
yl1=zeros(numero_colonne,T);

mf1=zeros(numero_colonne,1); 

Ep2=zeros(numero_colonne,1);
If2=zeros(numero_colonne,1);
Ep1=zeros(numero_colonne,1);
If1=zeros(numero_colonne,1);

sigma_p = 50;%sqrt(3/dt)sqrt(5/dt)
sigma_f = 50;
rng(7)  
np2 = randn(numero_colonne,T)*sigma_p;
nf2 = randn(numero_colonne,T)*sigma_f;
rng(6)
np1 = randn(numero_colonne,T)*sigma_p;
nf1 = randn(numero_colonne,T)*sigma_f;


J=size(all_patterns,2);
Wp_L2L1_store = cell(1, J);
w = waitbar(0,'Training L1 - L2 ...','WindowStyle','modal');
% for  k=1:T-1
  

% end    
    
    
 sequence = [1, 2, 3, 4, 5, 6, 7, 8,9,10];
N_item = length(sequence);
alpha = exp(0.5* ((1:N_item) - N_item));  % 最近的最大0.5
for  idx = 1:N_item
    j = sequence(idx);
    % eta = 5 * alpha(idx);%1
     eta =1;%不执行TOJ任务需要--模式1，TOJ模式3    
         % mp2=zeros(numero_colonne,1);
   for  k=1:T-1
        mp2=all_patterns(:,j)*2000;
        mp1=all_patterns(:,j)*2000;

          up2=np0(:,k)+mp2;
        uf2=nf2(:,k)+mf2;
        up1=np1(:,k)+mp1;
        uf1=nf1(:,k)+mf1;
        if (k>D_intraLayer)
% 
%              Inib=20-sum(zp1(:,k-D_intraLayer));
%          Inibitore=(abs(Inib) + Inib)/2; 
%         If2=K_L2L2*yp2(:,k-D_intraLayer)+A_L2L2*zp2(:,k-D_intraLayer)+1000*Inibitore;
            If2=K_L2L2*yp2(:,k-D_intraLayer)+A_L2L2*zp2(:,k-D_intraLayer);
            
        end
        if(k>D_extraLayer)
            Ep1=Wp_L1WM*yp0(:,k-D_extraLayer)+Wp_L1L1*yp1(:,k-D_intraLayer);
            Ep2=Wp_L2L1*yp1(:,k-D_extraLayer);
            %input extra-layer solo dal maestro!
        end
        
        %potenziali post-sinaptici: (comb lin degli outputs standard)
        vp2(:)=C(:,2).*ye2(:,k)-C(:,4).*ys2(:,k)-C(:,7).*yf2(:,k)+Ep2;
        ve2(:)=C(:,1).*yp2(:,k);
        vs2(:)=C(:,3).*yp2(:,k);
        vf2(:)=C(:,6).*yp2(:,k)-C(:,5).*ys2(:,k)-C(:,8).*yf2(:,k)+yl2(:,k)+If2;
        %spikes:
        zp2(:,k)=2*e0./(1+exp(-r*(vp2(:)-s0)));
        ze2(:,k)=2*e0./(1+exp(-r*(ve2(:)-s0)));
        zs2(:,k)=2*e0./(1+exp(-r*(vs2(:)-s0)));
        zf2(:,k)=2*e0./(1+exp(-r*(vf2(:)-s0)));
        
        %potenziali post-sinaptici: (comb lin degli outputs standard)
        vp1(:)=C(:,2).*ye1(:,k)-C(:,4).*ys1(:,k)-C(:,7).*yf1(:,k)+Ep1;
        ve1(:)=C(:,1).*yp1(:,k);
        vs1(:)=C(:,3).*yp1(:,k);
        vf1(:)=C(:,6).*yp1(:,k)-C(:,5).*ys1(:,k)-C(:,8).*yf1(:,k)+yl1(:,k)+If1;
        %spikes:
        zp1(:,k)=2*e0./(1+exp(-r*(vp1(:)-s0)));
        ze1(:,k)=2*e0./(1+exp(-r*(ve1(:)-s0)));
        zs1(:,k)=2*e0./(1+exp(-r*(vs1(:)-s0)));
        zf1(:,k)=2*e0./(1+exp(-r*(vf1(:)-s0)));
        

        % 
        % for pre = 1:400
        %     for post= 1:400
        %         if zp1(pre,k)>0 && zp2(post,k)>0
        %             % 如果两个神经元同时激活，增强权重
        %             Wp_L2L1(pre, post) = Wp_L2L1(pre, post) + learning_rate* zp1(pre,k) .*zp2(post,k);
        %         elseif zp1(pre,k)>0 && zp2(post,k)<=0
        %             % 如果前一个神经元激活而后者不激活，衰减权重
        %             Wp_L2L1(pre, post) = Wp_L2L1(pre,post) - weight_decay*zp1(pre,k);
        %         elseif zp1(pre,k)<=0 && zp2(post,k)>0
        %             % 如果后一个神经元激活而前者不激活，衰减权重
        %             Wp_L2L1(pre, post) = Wp_L2L1(pre,post) ;
        %         end
        %     end
        % end
        % learning_rate = learning_rate * (1 / (1 +k * rate_decay));
        % 
        % % 限制权重范围
        % Wp_L2L1 = max(Wp_L2L1, 0);  

        % 
        % 
        % 
        % 
        % 


        % %aggiornamento sinapsi...
        if k>600
            pj1=sum(zp1(:,k-499:k),2)*1/500;
            ATT_PRE=(pj1/(2*e0)- thresh_low1 )'; %1x400
            ATT_PRE(ATT_PRE<0)=0;
            ATT_POST=(zp2(:,k)/(2*e0)- thresh_low2); %400x1
           ATT_POST(ATT_POST<0)=0;
            WEIGHT=Wp_L2L1_max.*(ones(numero_colonne, numero_colonne)) - Wp_L2L1;
           Wp_L2L1 = Wp_L2L1 + eta*1/tau2*1/(1-thresh_low1)^2 .* (ATT_POST * ATT_PRE) .* WEIGHT;
           % Wp_L2L1 = max(Wp_L2L1, 0);  

        % 
        % 
        % 
        end
        
        xp2(:,k+1)=xp2(:,k)+(G(1)*a(1)*zp2(:,k)-2*a(1)*xp2(:,k)-a(1)*a(1)*yp2(:,k))*dt;
        yp2(:,k+1)=yp2(:,k)+xp2(:,k)*dt;
        xe2(:,k+1)=xe2(:,k)+(G(1)*a(1)*(ze2(:,k)+up2(:)./C(:,2))-2*a(1)*xe2(:,k)-a(1)*a(1)*ye2(:,k))*dt;
        ye2(:,k+1)=ye2(:,k)+xe2(:,k)*dt;
        xs2(:,k+1)=xs2(:,k)+(G(2)*a(2)*zs2(:,k)-2*a(2)*xs2(:,k)-a(2)*a(2)*ys2(:,k))*dt;
        ys2(:,k+1)=ys2(:,k)+xs2(:,k)*dt;
        xl2(:,k+1)=xl2(:,k)+(G(1)*a(1)*uf2(:)-2*a(1)*xl2(:,k)-a(1)*a(1)*yl2(:,k))*dt;
        yl2(:,k+1)=yl2(:,k)+xl2(:,k)*dt;
        xf2(:,k+1)=xf2(:,k)+(G(3)*a(3)*zf2(:,k)-2*a(3)*xf2(:,k)-a(3)*a(3)*yf2(:,k))*dt;
        yf2(:,k+1)=yf2(:,k)+xf2(:,k)*dt;
        
        xp1(:,k+1)=xp1(:,k)+(G(1)*a(1)*zp1(:,k)-2*a(1)*xp1(:,k)-a(1)*a(1)*yp1(:,k))*dt;
        yp1(:,k+1)=yp1(:,k)+xp1(:,k)*dt;
        xe1(:,k+1)=xe1(:,k)+(G(1)*a(1)*(ze1(:,k)+up1(:)./C(:,2))-2*a(1)*xe1(:,k)-a(1)*a(1)*ye1(:,k))*dt;
        ye1(:,k+1)=ye1(:,k)+xe1(:,k)*dt;
        xs1(:,k+1)=xs1(:,k)+(G(2)*a(2)*zs1(:,k)-2*a(2)*xs1(:,k)-a(2)*a(2)*ys1(:,k))*dt;
        ys1(:,k+1)=ys1(:,k)+xs1(:,k)*dt;
        xl1(:,k+1)=xl1(:,k)+(G(1)*a(1)*uf1(:)-2*a(1)*xl1(:,k)-a(1)*a(1)*yl1(:,k))*dt;
        yl1(:,k+1)=yl1(:,k)+xl1(:,k)*dt;
        xf1(:,k+1)=xf1(:,k)+(G(3)*a(3)*zf1(:,k)-2*a(3)*xf1(:,k)-a(3)*a(3)*yf1(:,k))*dt;
        yf1(:,k+1)=yf1(:,k)+xf1(:,k)*dt;
        
   end   
    Wp_L2L1_store{j} = Wp_L2L1;
    waitbar(j/J,w);
 end
  
close(w)

for i=1:numero_colonne
    S=sum(Wp_L2L1(i,:),2); %somma dei pesi sinaptici ricevuti dalla i-esima colonna
    if S>TOTSINW2
        Wp_L2L1(i,:)=Wp_L2L1(i,:).*(TOTSINW2/S);
    end
end

