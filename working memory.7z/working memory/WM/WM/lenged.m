% -------------------------- 1. 定义10种颜色（对应Object 1~10） --------------------------
nature_colors = [
    0.878 0.78  0.941 ;  % 1:浅紫粉-Object1
    0.933 0.467  0.2   ;  % 2:橙红-Object2
    0.2   0.667  0.933 ;  % 3:亮蓝-Object3
    0.733 0.733  0.733 ;  % 4:浅灰-Object4
    0.5   0.294  0.816 ;  % 5:深紫-Object5
    0.8   0.2    0.067 ;  % 6:暗红-Object6
    0     0.467  0.741 ;  % 7:深蓝-Object7
    0.984 0.835  0.667 ;  % 8:浅橙-Object8
    0     0.6    0.533 ;  % 9:青绿-Object9
    0.902 0.353  0.314 ;  % 10:橙粉-Object10
];

% -------------------------- 2. 创建图窗环境 --------------------------
figure('Position', [100, 100, 700, 500], 'Color', 'white');
hold on;

% -------------------------- 3. 绘制示例数据（可选，用于展示） --------------------------
x = 0:0.1:5;
for i = 1:10
    % 绘制10条不同颜色的曲线（模拟10个物体数据）
    y = i * sin(x) + i;
    plot(x, y, 'Color', nature_colors(i,:), 'LineWidth', 1.5);
end

% 设置坐标轴
xlabel('X Value', 'FontSize', 11);
ylabel('Y Value', 'FontSize', 11);
title('Data with 10 Objects', 'FontSize', 13);
xlim([0, 5]);
ylim([0, 12]);
set(gca, 'FontSize', 10);
box on;

% -------------------------- 4. 创建图例专用圆点标记（核心步骤） --------------------------
% 初始化句柄数组存储圆点标记
marker_handles = gobjects(1, 10);

for i = 1:10
    % 绘制隐藏的圆点（仅用于图例，不显示在图中）
    marker_handles(i) = plot(NaN, NaN, 'o', ...  % NaN确保点不显示在图中
                            'MarkerSize', 8, ...  % 圆点大小
                            'MarkerFaceColor', nature_colors(i,:), ...  % 填充色
                            'MarkerEdgeColor', 'none', ...  % 无边框
                            'LineWidth', 1.2);  % 线条宽度（不影响圆点）
end

% -------------------------- 5. 创建图例（圆点标记+黑色文字） --------------------------
leg = legend(marker_handles, ...  % 关联圆点标记句柄
             'Object 1', 'Object 2', 'Object 3', 'Object 4', 'Object 5', ...
             'Object 6', 'Object 7', 'Object 8', 'Object 9', 'Object 10', ...
             'Location', 'best', ...
             'NumColumns', 2, ...  % 2列布局
             'FontSize', 10, ...
             'Color', 'white', ...  % 白色背景
             'EdgeColor', 'none');  % 无边框

% 强制图例文字为黑色并加粗
text_objs = findobj(leg, 'Type', 'Text');
set(text_objs, ...
    'Color', [0 0 0], ...        % 纯黑色
    'FontWeight', 'bold', ...    % 加粗
    'FontName', 'Arial');        % 无衬线字体

hold off;
    