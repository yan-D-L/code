function [im] = vecToIm(X,n,m)
% n = 11;
% m = 15;
% X = column vector

im=X(1:m)';
for k=1:n-1
   im=[im; X(k*m+1:k*m+m)'];
end

end

