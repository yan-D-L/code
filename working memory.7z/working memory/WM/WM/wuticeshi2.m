clear
clc
close all

%% 1. 基础参数与图案定义
N=11;  % Y轴像素数(1-11)
M=15;  % X轴像素数(1-15)
P=zeros(M*N,1);
all_patterns=zeros(N*M,10);

% 10个图案位置（保留你的原始定义）
P1=P(:); pos1=[19:24 34:39 49:52]; P1(pos1)=1; all_patterns(:,1)=P1;
P2=P(:); pos2=[66:71 81:82 96:97 111:116]; P2(pos2)=1; all_patterns(:,2)=P2;
P3=P(:); pos3=[8:12 25:29 40:42 53:55]; P3(pos3)=1; all_patterns(:,3)=P3;
P4=P(:); pos4=[13:15 43:45 56:57 145:150 153:154]; P4(pos4)=1; all_patterns(:,4)=P4;
P5=P(:); pos5=[61:65 76:78 91:93 106:110 ]; P5(pos5)=1; all_patterns(:,5)=P5;
P6=P(:); pos6=[98:103 130:135 128:129 151:152]; P6(pos6)=1; all_patterns(:,6)=P6;
P7=P(:); pos7=[58:60 72:75 84:90 104:105]; P7(pos7)=1; all_patterns(:,7)=P7;
P8=P(:); pos8=[79:80 117:120 137:138 158:165]; P8(pos8)=1; all_patterns(:,8)=P8;
P9=P(:); pos9=[94:95 121:127 140:144 155:156]; P9(pos9)=1; all_patterns(:,9)=P9;
P10=P(:); pos10=[1:7 16:18 31:33 46:48]; P10(pos10)=1; all_patterns(:,10)=P10;

%% 2. 颜色叠加（保留你的逻辑）
nature_colors = [
   0.878 0.78  0.941 ; 0.933 0.467  0.2   ; 0.2   0.667  0.933 ; 0.733 0.733  0.733 ;
   0.5   0.294  0.816 ; 0.8   0.2    0.067 ; 0     0.467  0.741 ; 0.984 0.835  0.667 ;
   0     0.6    0.533 ; 0.902 0.353  0.314 
];

RGB = ones(N, M, 3);
alpha = 1;
for i = 1:10
    pattern_img = reshape(all_patterns(:,i), M, N)';  % 直接转置，省略函数
    mask = double(pattern_img > 0);
    for c = 1:3
        RGB(:,:,c) = RGB(:,:,c) - alpha * mask .* (1 - nature_colors(i, c));
    end
end
RGB = min(max(RGB, 0), 1);

%% 3. 绘图核心（确保图例显示的关键）
figure('Position', [100, 100, 900, 500]);  % 加宽画布，预留图例空间
ax = axes('Parent', gcf);
hold(ax, 'on');

% 显示图像：像素与轴精准对应（无空白条）
image(ax, 1:M, 1:N, RGB);
axis(ax, 'image');
axis(ax, 'tight');
xlim(ax, [0.5, M+0.5]);  % 贴合像素边缘
ylim(ax, [0.5, N+0.5]);

% 轴设置：仅左下轴
ax.XAxisLocation = 'bottom';
ax.YAxisLocation = 'left';
ax.Box = 'off';
ax.XTick = 1:M; ax.YTick = 1:N;
ax.XLabel.String = 'Cortical Column Index (Pixel Column)';
ax.YLabel.String = 'Cortical Column Index (Pixel Row)';
ax.FontSize = 9;

%% 4. 生成有效图例（100%显示的核心）
legend_handles = [];
legend_labels = {};

% 关键：先绘制可见点→再隐藏，生成有效句柄
for i = 1:10
    % 绘制一个不在图像范围内的点（有效句柄，但不可见）
    h = plot(ax, -10, -10, 's', ...  % 坐标-10,-10，在图像外
        'MarkerFaceColor', nature_colors(i,:), ...
        'MarkerEdgeColor', nature_colors(i,:), ...
        'MarkerSize', 8);
    legend_handles = [legend_handles, h];  % 收集句柄
    legend_labels = [legend_labels, sprintf('Object %d', i)];
end

% 创建图例：强制显示在右侧，指定尺寸
lgd = legend(ax, legend_handles, legend_labels);
lgd.Location = 'eastoutside';  % 右侧外部
lgd.Position = [0.8, 0.1, 0.06, 0.4];  % 图例位置（左0.8，下0.1，宽0.15，高0.8）
lgd.LineWidth = 0.5;
lgd.FontSize = 9;
lgd.Visible = 'on';  % 强制可见

title(ax, 'All 10 orthogonal objects', 'FontSize', 12);
hold(ax, 'off');