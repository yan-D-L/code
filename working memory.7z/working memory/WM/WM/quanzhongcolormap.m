
load('sinapsi_SET12.mat')
% % 绘制色图
imagesc(Wp_L1WM);

% 添加颜色条
colorbar;
set(gca, 'YDir', 'normal');
% 设置坐标轴标签
xlabel('L1');
ylabel('WM');

% 设置标题
title('The weight connection from the WM layer to the L1 layer');
% figure; % 创建新图形窗口
% for i = 1:10
%     subplot(2, 5, i); % 创建 2x5 的子图布局
%     imagesc(Wp_L1WM_store{i}); % 显示每个单元格的矩阵
%     colorbar; % 添加色条以显示色彩映射的范围
%     title(['Matrix ', num2str(i)]); % 设置标题
%     axis square; % 确保每个子图是方形的
% end
% sgtitle('Wp_L1WM 顺序[1,2,3,4,5,6,7,8,9,10]'); % 设置总标题