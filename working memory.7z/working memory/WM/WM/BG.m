% 参数定义
num_neurons = 100;  % 神经元数量
time_steps = 1000;  % 模拟时间步数
dt = 0.1;           % 时间步长

% 神经元电位初始化
u_p = zeros(num_neurons, time_steps);  % 锥体细胞
u_f = zeros(num_neurons, time_steps);  % 快抑制性中间神经元
u_s = zeros(num_neurons, time_steps);  % 慢抑制性中间神经元

% 基底神经节参数和选择性抑制函数
W_direct = 1.5;       % 基底神经节直接通路的权重
W_indirect = -1.0;    % 基底神经节间接通路的权重

% 网络连接权重初始化 (示例值, 可根据需求调整)
C_ep = 0.8;   % Excitatory to Pyramidal
C_pe = 0.7;   % Pyramidal to Excitatory
C_ps = 0.6;   % Pyramidal to Slow Inhibitory
C_sp = -0.4;  % Slow Inhibitory to Pyramidal
C_pf = 0.5;   % Pyramidal to Fast Inhibitory
C_fp = -0.3;  % Fast Inhibitory to Pyramidal

% 输入刺激
input_stimulus = zeros(num_neurons, time_steps);
input_stimulus(:, 200:400) = 1.0;  % 输入刺激在200到400步内激活

% 模拟过程
for t = 2:time_steps
    % 锥体细胞更新
    excitatory_input = C_ep * u_p(:, t-1) + C_pe * u_p(:, t-1) + input_stimulus(:, t);
    inhibitory_input = C_ps * u_s(:, t-1) + C_fp * u_f(:, t-1);
    
    % 丘脑-基底神经节选择性更新机制
    % 通过直接通路 (促进选择性激活) 和间接通路 (选择性抑制)
    thalamic_update = W_direct * excitatory_input + W_indirect * inhibitory_input;
    
    % 锥体细胞更新方程
    u_p(:, t) = u_p(:, t-1) + dt * (-u_p(:, t-1) + excitatory_input + thalamic_update);
    
    % 快抑制性中间神经元更新
    u_f(:, t) = u_f(:, t-1) + dt * (-u_f(:, t-1) + C_pf * u_p(:, t-1));
    
    % 慢抑制性中间神经元更新
    u_s(:, t) = u_s(:, t-1) + dt * (-u_s(:, t-1) + C_ps * u_p(:, t-1));
    
    % 基底神经节更新机制控制
    % 如果满足条件，则激活选择性更新或抑制
    if mean(u_p(:, t)) > 0.5  % 假设一个阈值条件来决定是否更新
        % 激活直接通路，强化特定记忆
        W_direct = W_direct + 0.1 * (1 - W_direct);
    else
        % 激活间接通路，抑制非目标记忆
        W_indirect = W_indirect - 0.1 * W_indirect;
    end
end

% 绘图
time = (1:time_steps) * dt;
figure;
subplot(3,1,1);
plot(time, mean(u_p, 1), 'b');
title('Pyramidal Neuron Activity');
xlabel('Time');
ylabel('Activity');

subplot(3,1,2);
plot(time, mean(u_f, 1), 'r');
title('Fast Inhibitory Interneurons');
xlabel('Time');
ylabel('Activity');

subplot(3,1,3);
plot(time, mean(u_s, 1), 'g');
title('Slow Inhibitory Interneurons');
xlabel('Time');
ylabel('Activity');