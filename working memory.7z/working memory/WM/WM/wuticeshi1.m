clear
clc
close all

%% 1. 基础参数与4个图案定义
disp("choose the pattern with variable dimensions (number 2)")
N=11;  % Y轴像素数(1-11)
M=15;  % X轴像素数(1-15)
numero_colonne=N*M;

P=zeros(M*N,1);
all_patterns=zeros(N*M,4);

% 定义4个图案的位置
P1=P(:); pos1=[19:24 34:39 49:52]; P1(pos1)=1; all_patterns(:,1)=P1;
P2=P(:); pos2=[66:71 41:42 54:55 111:116]; P2(pos2)=1; all_patterns(:,2)=P2;
P3=P(:); pos3=[8:12 25:29 40:42 53:55]; P3(pos3)=1; all_patterns(:,3)=P3;
P4=P(:); pos4=[13:15 43:45 49:52 145:150]; P4(pos4)=1; all_patterns(:,4)=P4;

%% 2. 颜色叠加
nature_colors = [
   0.878 0.78  0.941 ;  % #E0C5F2 (Object1)
   0.933 0.467  0.2   ;  % #EE7733 (Object2)
   0.2   0.667  0.933 ;  % #33BBEE (Object3)
   0.733 0.733  0.733 ;  % #BBBBBB (Object4)
];

RGB = ones(N, M, 3);  % 11行×15列
alpha = 1;  % 透明度
for i = 1:4
    pattern_img = reshape(all_patterns(:,i), M, N)';  
    mask = double(pattern_img > 0);
    for c = 1:3
        RGB(:,:,c) = RGB(:,:,c) - alpha * mask .* (1 - nature_colors(i, c));
    end
end
RGB = min(max(RGB, 0), 1);

%% 3. 绘图核心（彻底解决右侧边框过粗）
figure('Position', [100, 100, 900, 450]);  
ax = axes('Parent', gcf);
hold(ax, 'on');

% 显示图像（关键：缩小图像范围，避免和坐标轴重叠）
image(ax, 1:M, 1:N, RGB);  
axis(ax, 'image');         
xlim(ax, [0.5, M+0.5]);   % 扩展X轴范围，让边框和图像边缘分离
ylim(ax, [0.5, N+0.5]);

% 轴基础设置（关闭默认Box，手动绘制四条边框）
ax.XAxisLocation = 'bottom';
ax.YAxisLocation = 'left';
ax.Box = 'off';  % 关闭默认Box，避免重叠
ax.XTick = 1:M; 
ax.YTick = 1:N; 
ax.XTickLabel = ax.XTick;
ax.YTickLabel = ax.YTick;

% ========== 核心修复：手动绘制四条等宽边框 ==========
border_color = [0 0 0];    % 边框颜色（黑色）
border_width = 0.5;          % 统一边框宽度（可自定义）
ax.LineWidth = border_width;
ax.XColor = border_color;
ax.YColor = border_color;
ax.Color = 'none';

% 手动绘制四条边框（精准定位，避免重叠）
% 下边框（X轴）：y=0，x从0到M+1
plot(ax, [0.5, M+0.5], [0.5, 0.5], 'Color', border_color, 'LineWidth', border_width);
% 上边框：y=N+1，x从0到M+1
plot(ax, [0.5, M+0.5], [N+0.5, N+0.5], 'Color', border_color, 'LineWidth', border_width);
% 左边框（Y轴）：x=0，y从0到N+1
plot(ax, [0.5, 0.5], [0.5, N+0.5], 'Color', border_color, 'LineWidth', border_width);
% 右边框：x=M+1，y从0到N+1
plot(ax, [M+0.5, M+0.5], [0.5, N+0.5], 'Color', border_color, 'LineWidth', border_width);

% 轴标题与样式
xlabel(ax, 'Cortical Column Index (Pixel Column)', 'FontSize', 12, 'FontName', 'Arial');
ylabel(ax, 'Cortical Column Index (Pixel Row)', 'FontSize', 12, 'FontName', 'Arial');
ax.FontName = 'Arial';
ax.FontSize = 9;  

% 标题
title(ax, 'All 4 objects with overlapping features', 'FontSize', 12);

%% 4. 图例显示（添加白色背景）
% 计算组合对象颜色
combined_color1 = [1, 1, 1];  % Object1+Object4
for i = [1, 4]
    for c = 1:3
        combined_color1(c) = combined_color1(c) - (1 - nature_colors(i, c));
    end
end
combined_color1 = max(min(combined_color1, 1), 0);

combined_color2 = [1, 1, 1];  % Object2+Object3
for i = [2, 3]
    for c = 1:3
        combined_color2(c) = combined_color2(c) - (1 - nature_colors(i, c));
    end
end
combined_color2 = max(min(combined_color2, 1), 0);

% 生成图例句柄
h1 = plot(ax, NaN, NaN, 's', 'MarkerFaceColor', nature_colors(1,:), 'MarkerEdgeColor', nature_colors(1,:), 'MarkerSize', 10);
h2 = plot(ax, NaN, NaN, 's', 'MarkerFaceColor', nature_colors(2,:), 'MarkerEdgeColor', nature_colors(2,:), 'MarkerSize', 10);
h3 = plot(ax, NaN, NaN, 's', 'MarkerFaceColor', nature_colors(3,:), 'MarkerEdgeColor', nature_colors(3,:), 'MarkerSize', 10);
h4 = plot(ax, NaN, NaN, 's', 'MarkerFaceColor', nature_colors(4,:), 'MarkerEdgeColor', nature_colors(4,:), 'MarkerSize', 10);
h14 = plot(ax, NaN, NaN, 's', 'MarkerFaceColor', combined_color1, 'MarkerEdgeColor', combined_color1, 'MarkerSize', 10);
h23 = plot(ax, NaN, NaN, 's', 'MarkerFaceColor', combined_color2, 'MarkerEdgeColor', combined_color2, 'MarkerSize', 10);

% 创建图例（核心：添加白色背景）
lgd = legend(ax, [h1,h2,h3,h4,h14,h23], ...
    {'Object 1','Object 2','Object 3','Object 4','Object 1+Object 4','Object 2+Object 3'});
lgd.Location = 'eastoutside';
lgd.Position = [0.85, 0.15, 0.1, 0.7];
lgd.LineWidth = 0.5;
lgd.FontName = 'Arial';
lgd.FontSize = 9;
lgd.Visible = 'on';
% ========== 新增：设置图例白色背景 ==========
lgd.Box = 'on'; 
lgd.BackgroundColor = [1 1 1];  % 图例背景设为纯白色
lgd.EdgeColor = [0 0 0];  % 可选：图例边框设为浅灰色，增强视觉区分（可删）

hold(ax, 'off');